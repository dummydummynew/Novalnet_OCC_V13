package org.novalnetbackoffice.constants;

/**
 * Global class for all Ybackoffice constants. You can add global constants for your extension into this class.
 */
public final class YacceleratorbackofficeConstants extends GeneratedYacceleratorbackofficeConstants {
    public static final String EXTENSIONNAME = "novalnetbackoffice";

    private YacceleratorbackofficeConstants() {
        //empty to avoid instantiating this constant class
    }
}

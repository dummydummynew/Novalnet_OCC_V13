/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 09-Feb-2026, 12:35:47 pm                    ---
 * ----------------------------------------------------------------
 *  
 * Copyright (c) 2026 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.novalnet.core.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedNovalnetCoreConstants
{
	public static final String EXTENSIONNAME = "novalnetcore";
	public static class TC
	{
		public static final String NOVALNETCALLBACKINFO = "NovalnetCallbackInfo".intern();
		public static final String NOVALNETPAYMENTINFO = "NovalnetPaymentInfo".intern();
		public static final String NOVALNETPAYMENTMODE = "NovalnetPaymentMode".intern();
	}
	public static class Attributes
	{
		public static class BaseStore
		{
			public static final String NOVALNETAPIKEY = "novalnetAPIKey".intern();
			public static final String NOVALNETDISPLAYPAYMENTS = "novalnetDisplayPayments".intern();
			public static final String NOVALNETPAYMENTACCESSKEY = "novalnetPaymentAccessKey".intern();
			public static final String NOVALNETTARIFFID = "novalnetTariffId".intern();
			public static final String NOVALNETVENDORSCRIPTTESTMODE = "novalnetVendorscriptTestMode".intern();
			public static final String NOVALNETVENDORSCRIPTTOEMAILADDRESS = "novalnetVendorscriptToEmailAddress".intern();
		}
	}
	
	protected GeneratedNovalnetCoreConstants()
	{
		// private constructor
	}
	
	
}

package de.hybris.novalnet.core.constants;

/**
 * Global class for all NovalnetCore constants. You can add global constants for your extension into this class.
 */
public final class NovalnetCoreConstants extends GeneratedNovalnetCoreConstants {
    public static final String EXTENSIONNAME = "novalnetcore";

    private NovalnetCoreConstants() {
        //empty
    }
}

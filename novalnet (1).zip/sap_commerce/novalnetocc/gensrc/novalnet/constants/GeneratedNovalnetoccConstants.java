/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 09-Feb-2026, 12:35:47 pm                    ---
 * ----------------------------------------------------------------
 */
package novalnet.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedNovalnetoccConstants
{
	public static final String EXTENSIONNAME = "novalnetocc";
	
	protected GeneratedNovalnetoccConstants()
	{
		// private constructor
	}
	
	
}

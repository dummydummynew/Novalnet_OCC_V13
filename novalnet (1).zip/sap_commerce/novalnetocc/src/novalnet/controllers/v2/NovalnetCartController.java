package novalnet.controllers.v2;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import de.hybris.platform.commerceservices.request.mapping.annotation.ApiVersion;
import de.hybris.platform.commercewebservicescommons.annotation.SiteChannelRestriction;
import de.hybris.platform.webservicescommons.mapping.DataMapper;
import de.hybris.platform.webservicescommons.swagger.ApiBaseSiteIdUserIdAndCartIdParam;
import de.hybris.platform.webservicescommons.swagger.ApiFieldsParam;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import novalnet.dto.payment.NnPaymentResponseWsDTO;
import novalnet.dto.payment.NnRequestWsDTO;
import de.novalnet.beans.NnPaymentResponseData;
import de.novalnet.beans.NnRequestData;
import de.novalnet.checkout.NovalnetCheckoutFacade;

import static de.hybris.platform.webservicescommons.mapping.FieldSetLevelHelper.DEFAULT_LEVEL;

@Controller
@RequestMapping("/{baseSiteId}/novalnet")
@ApiVersion("v2")
@Api(tags = "Novalnet Cart")
public class NovalnetCartController {

    private static final Logger LOG =
            Logger.getLogger(NovalnetCartController.class);

    protected static final String API_COMPATIBILITY_B2B_CHANNELS =
            "api.compatibility.b2b.channels";

    @Resource
    private NovalnetCheckoutFacade novalnetCheckoutFacade;

    @Resource
    private DataMapper dataMapper;

    @Secured({ "ROLE_CUSTOMERGROUP", "ROLE_CLIENT",
               "ROLE_CUSTOMERMANAGERGROUP", "ROLE_TRUSTED_CLIENT" })
    @PostMapping(
            value = "/getPaymentURL",
            consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    @SiteChannelRestriction(
            allowedSiteChannelsProperty = API_COMPATIBILITY_B2B_CHANNELS)
    @ApiOperation(
            nickname = "getPaymentURL",
            value = "Get Novalnet hosted payment URL")
    @ApiBaseSiteIdUserIdAndCartIdParam
    public NnPaymentResponseWsDTO getPaymentURL(
            @ApiParam(required = true)
            @RequestBody final NnRequestWsDTO requestWsDTO,
            @ApiFieldsParam
            @RequestParam(defaultValue = DEFAULT_LEVEL) final String fields,
            final HttpServletRequest httpRequest) {

        final NnRequestData request =
                dataMapper.map(requestWsDTO, NnRequestData.class, fields);

        final NnPaymentResponseData response =
                novalnetCheckoutFacade.getHostedPaymentUrl(request, httpRequest);

        return dataMapper.map(
                response,
                NnPaymentResponseWsDTO.class,
                fields);
    }
}

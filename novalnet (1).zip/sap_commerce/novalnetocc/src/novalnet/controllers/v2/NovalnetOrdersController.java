package novalnet.controllers.v2;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import de.hybris.platform.commerceservices.request.mapping.annotation.ApiVersion;
import de.hybris.platform.commercewebservicescommons.annotation.SiteChannelRestriction;
import de.hybris.platform.webservicescommons.mapping.DataMapper;
import de.hybris.platform.webservicescommons.swagger.ApiBaseSiteIdAndUserIdParam;
import de.hybris.platform.webservicescommons.swagger.ApiFieldsParam;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import novalnet.dto.payment.*;
import de.novalnet.beans.*;
import de.novalnet.checkout.NovalnetCheckoutFacade;

import static de.hybris.platform.webservicescommons.mapping.FieldSetLevelHelper.DEFAULT_LEVEL;

@Controller
@RequestMapping("/{baseSiteId}/novalnet/orders")
@ApiVersion("v2")
@Api(tags = "Novalnet Orders")
public class NovalnetOrdersController {

    private static final Logger LOG =
            Logger.getLogger(NovalnetOrdersController.class);

    protected static final String API_COMPATIBILITY_B2B_CHANNELS =
            "api.compatibility.b2b.channels";

    @Resource
    private NovalnetCheckoutFacade novalnetCheckoutFacade;

    @Resource
    private DataMapper dataMapper;
       
    @Secured({ "ROLE_CUSTOMERGROUP", "ROLE_CLIENT",
               "ROLE_CUSTOMERMANAGERGROUP", "ROLE_TRUSTED_CLIENT" })
    @PostMapping(
            value = "/placeOrder",
            consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    @SiteChannelRestriction(
            allowedSiteChannelsProperty = API_COMPATIBILITY_B2B_CHANNELS)
    @ApiOperation(
            nickname = "placeOrder",
            value = "Place order")
    @ApiBaseSiteIdAndUserIdParam
    public NnPlaceOrderResponseWsDTO placeOrder(
            @ApiParam(required = true)
            @RequestBody final NnRequestWsDTO requestWsDTO,
            @ApiFieldsParam
            @RequestParam(defaultValue = DEFAULT_LEVEL) final String fields,
            final HttpServletRequest httpRequest) {

        final NnRequestData request =
                dataMapper.map(requestWsDTO, NnRequestData.class, fields);
                
        NnPlaceOrderResponseData response = new NnPlaceOrderResponseData();
                
        response.setOrderInfo(
			    novalnetCheckoutFacade.placeOrderFromTid(request));

        return dataMapper.map(response,
                NnPlaceOrderResponseWsDTO.class, fields);
    }

    @Secured({ "ROLE_CUSTOMERGROUP", "ROLE_CLIENT",
               "ROLE_CUSTOMERMANAGERGROUP", "ROLE_TRUSTED_CLIENT" })
    @PostMapping(
            value = "/initiateTransaction",
            consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    @SiteChannelRestriction(
            allowedSiteChannelsProperty = API_COMPATIBILITY_B2B_CHANNELS)
    @ApiOperation(
            nickname = "initiateTransaction",
            value = "Initiate transaction with Novalnet")
    @ApiBaseSiteIdAndUserIdParam
    public NnTransactionResponseWsDTO initiateTransaction(
            @ApiParam(required = true)
            @RequestBody final NnRequestWsDTO requestWsDTO,
            @ApiFieldsParam
            @RequestParam(defaultValue = DEFAULT_LEVEL) final String fields,
            final HttpServletRequest httpRequest) {

        final NnRequestData request =
                dataMapper.map(requestWsDTO, NnRequestData.class, fields);

        final NnTransactionResponseData response =
                novalnetCheckoutFacade.placeTransaction(request, httpRequest);

        return dataMapper.map(response,
                NnTransactionResponseWsDTO.class, fields);
    }

    @Secured({ "ROLE_CUSTOMERGROUP", "ROLE_CLIENT",
               "ROLE_CUSTOMERMANAGERGROUP", "ROLE_TRUSTED_CLIENT" })
    @PostMapping(
            value = "/getRedirectURL",
            consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    @SiteChannelRestriction(
            allowedSiteChannelsProperty = API_COMPATIBILITY_B2B_CHANNELS)
    @ApiOperation(
            nickname = "redirectURL",
            value = "Get Novalnet redirect URL")
    @ApiBaseSiteIdAndUserIdParam
    public NnResponseWsDTO getRedirectURL(
            @ApiParam(required = true)
            @RequestBody final NnRequestWsDTO requestWsDTO,
            @ApiFieldsParam
            @RequestParam(defaultValue = DEFAULT_LEVEL) final String fields,
            final HttpServletRequest httpRequest) {

        final NnRequestData request =
                dataMapper.map(requestWsDTO, NnRequestData.class, fields);

        final NnResponseData response =
                novalnetCheckoutFacade.getRedirectUrl(request, httpRequest);

        return dataMapper.map(response,
                NnResponseWsDTO.class, fields);
    }

    @Secured({ "ROLE_CUSTOMERGROUP", "ROLE_CLIENT",
               "ROLE_CUSTOMERMANAGERGROUP", "ROLE_TRUSTED_CLIENT" })
    @PostMapping("/paymentDetails")
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    @SiteChannelRestriction(
            allowedSiteChannelsProperty = API_COMPATIBILITY_B2B_CHANNELS)
    @ApiOperation(
            nickname = "paymentDetails",
            value = "Get Novalnet payment details")
    @ApiBaseSiteIdAndUserIdParam
    public NnPaymentDetailsWsDTO getPaymentDetails(
            @ApiParam(required = true)
            @RequestParam final String orderno,
            @ApiFieldsParam
            @RequestParam(defaultValue = DEFAULT_LEVEL) final String fields) {
				
        final NnPaymentDetailsData details =
                novalnetCheckoutFacade.getPaymentDetails(orderno);
        return dataMapper.map(details,
                NnPaymentDetailsWsDTO.class, fields);
    }
}

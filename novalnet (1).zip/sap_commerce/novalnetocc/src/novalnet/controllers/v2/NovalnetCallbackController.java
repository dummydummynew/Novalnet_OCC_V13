package novalnet.controllers.v2;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import de.hybris.platform.commerceservices.request.mapping.annotation.ApiVersion;
import de.hybris.platform.webservicescommons.mapping.DataMapper;
import de.hybris.platform.webservicescommons.swagger.ApiBaseSiteIdAndUserIdParam;
import de.hybris.platform.webservicescommons.swagger.ApiFieldsParam;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import novalnet.dto.payment.NnCallbackRequestWsDTO;
import novalnet.dto.payment.NnCallbackResponseWsDTO;
import de.novalnet.callback.NovalnetCallbackFacade;
import de.novalnet.beans.NnCallbackRequestData;
import de.novalnet.beans.NnCallbackResponseData;

import static de.hybris.platform.webservicescommons.mapping.FieldSetLevelHelper.DEFAULT_LEVEL;

@Controller
@RequestMapping("/{baseSiteId}/novalnet")
@ApiVersion("v2")
@Api(tags = "Novalnet Callback")
public class NovalnetCallbackController {

    private static final Logger LOG =
            Logger.getLogger(NovalnetCallbackController.class);

    @Resource
    private NovalnetCallbackFacade novalnetCallbackFacade;

    @Resource
    private DataMapper dataMapper;
    

    @PostMapping("/callback")
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    @ApiOperation(
            nickname = "novalnetCallback",
            value = "Handle Novalnet webhook callback")
    @ApiBaseSiteIdAndUserIdParam
    public NnCallbackResponseWsDTO handleCallback(
            @ApiParam(required = true)
            @RequestBody final NnCallbackRequestWsDTO wsRequest,
            @ApiFieldsParam
            @RequestParam(defaultValue = DEFAULT_LEVEL) final String fields,
            final HttpServletRequest httpRequest) {

        final NnCallbackResponseData response = new NnCallbackResponseData();

        try {
            final NnCallbackRequestData callbackRequest =
                    dataMapper.map(wsRequest, NnCallbackRequestData.class, fields);

            final String result =
                    novalnetCallbackFacade.processCallback(callbackRequest, httpRequest);

            response.setMessage(result);

        } catch (Exception ex) {
            LOG.error("Novalnet callback failed", ex);
            response.setMessage(ex.getMessage());
        }

        return dataMapper.map(response, NnCallbackResponseWsDTO.class, fields);
    }
}

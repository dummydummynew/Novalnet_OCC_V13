package novalnet.controllers.v2;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import de.hybris.platform.commerceservices.request.mapping.annotation.ApiVersion;
import de.hybris.platform.commercewebservicescommons.annotation.SiteChannelRestriction;
import de.hybris.platform.webservicescommons.mapping.DataMapper;
import de.hybris.platform.webservicescommons.swagger.ApiBaseSiteIdAndUserIdParam;
import de.hybris.platform.webservicescommons.swagger.ApiFieldsParam;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import novalnet.dto.payment.NnConfigWsDTO;
import de.novalnet.beans.NnConfigData;
import de.novalnet.checkout.NovalnetCheckoutFacade;

import static de.hybris.platform.webservicescommons.mapping.FieldSetLevelHelper.DEFAULT_LEVEL;

@Controller
@RequestMapping("/{baseSiteId}/novalnet/config")
@ApiVersion("v2")
@Api(tags = "Novalnet Configuration")
public class NovalnetConfigController {

    private static final Logger LOG =
            Logger.getLogger(NovalnetConfigController.class);

    protected static final String API_COMPATIBILITY_B2B_CHANNELS =
            "api.compatibility.b2b.channels";

    @Resource
    private NovalnetCheckoutFacade novalnetCheckoutFacade;

    @Resource
    private DataMapper dataMapper;

    @Secured({ "ROLE_CUSTOMERGROUP", "ROLE_CLIENT",
               "ROLE_CUSTOMERMANAGERGROUP", "ROLE_TRUSTED_CLIENT" })
    @GetMapping("/details")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    @SiteChannelRestriction(
            allowedSiteChannelsProperty = API_COMPATIBILITY_B2B_CHANNELS)
    @ApiOperation(
            nickname = "paymentConfig",
            value = "Return Novalnet payment configuration")
    @ApiBaseSiteIdAndUserIdParam
    public NnConfigWsDTO getPaymentConfig(
            @ApiFieldsParam
            @RequestParam(defaultValue = DEFAULT_LEVEL) final String fields) {

        final NnConfigData config =
                novalnetCheckoutFacade.getPaymentConfiguration();

        return dataMapper.map(
                config,
                NnConfigWsDTO.class,
                fields);
    }
}

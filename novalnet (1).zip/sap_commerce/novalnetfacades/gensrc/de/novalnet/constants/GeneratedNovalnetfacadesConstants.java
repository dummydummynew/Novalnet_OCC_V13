/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 09-Feb-2026, 12:35:47 pm                    ---
 * ----------------------------------------------------------------
 */
package de.novalnet.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedNovalnetfacadesConstants
{
	public static final String EXTENSIONNAME = "novalnetfacades";
	
	protected GeneratedNovalnetfacadesConstants()
	{
		// private constructor
	}
	
	
}

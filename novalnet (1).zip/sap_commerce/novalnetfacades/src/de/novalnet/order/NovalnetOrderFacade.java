package de.novalnet.order;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import org.json.JSONObject;

import de.novalnet.dao.NovalnetOrderDao;
import de.novalnet.enums.NovalnetPaymentGatewayStatus;
import de.hybris.novalnet.core.model.NovalnetCallbackInfoModel;
import de.hybris.novalnet.core.model.NovalnetPaymentInfoModel;

import de.hybris.platform.commercefacades.order.CartFacade;
import de.hybris.platform.commercefacades.order.CheckoutFacade;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.commercefacades.user.UserFacade;

import de.hybris.platform.b2bacceleratorfacades.order.impl.DefaultB2BCheckoutFacade;

import de.hybris.platform.order.PaymentModeService;

import de.hybris.platform.commerceservices.customer.CustomerAccountService;
import de.hybris.platform.commerceservices.order.CommerceCheckoutService;
import de.hybris.platform.commerceservices.service.data.CommerceCheckoutParameter;
import de.hybris.platform.commerceservices.strategies.CheckoutCustomerStrategy;

import de.hybris.platform.commercewebservicescommons.errors.exceptions.RequestParameterException;
import de.hybris.platform.commercewebservicescommons.strategies.CartLoaderStrategy;

import de.hybris.platform.core.PK;
import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.core.enums.PaymentStatus;
import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.core.model.user.AddressModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.order.payment.PaymentModeModel;

import de.hybris.platform.orderhistory.model.OrderHistoryEntryModel;

import de.hybris.platform.payment.dto.TransactionStatus;
import de.hybris.platform.payment.enums.PaymentTransactionType;

import de.hybris.platform.payment.model.PaymentTransactionEntryModel;
import de.hybris.platform.payment.model.PaymentTransactionModel;

import de.hybris.platform.servicelayer.i18n.CommonI18NService;
import de.hybris.platform.servicelayer.model.ModelService;

import de.hybris.platform.webservicescommons.util.YSanitizer;

import de.hybris.platform.store.BaseStoreModel;
import de.hybris.platform.store.services.BaseStoreService;

import de.hybris.platform.order.CartService;

import de.hybris.platform.util.localization.Localization;

import de.novalnet.beans.NnRequestData;

import de.hybris.platform.order.InvalidCartException;

/**
 * Facade handling Novalnet order operations.
 */
public class NovalnetOrderFacade {

    private static final Logger LOG = Logger.getLogger(NovalnetOrderFacade.class);

    private static final int DAYS_IN_YEAR = 365;
    private static final int HOURS_IN_DAY = 24;
    private static final int MINUTES_IN_HOUR = 60;
    private static final int SECONDS_IN_MINUTE = 60;
    private static final int AGE_REQUIREMENT = 18;
    private static final String BR = "<br/>";
    private static final String STATUS_ON_HOLD = "ON_HOLD";
    private static final String ADDRESS_DOES_NOT_EXIST =
            "Address with given id '%s' does not exist or does not belong to the user";

    private final NovalnetOrderDao novalnetOrderDao;
    private final ModelService modelService;
    private final CartFacade cartFacade;
    private final DefaultB2BCheckoutFacade checkoutFacade;
    private final CartLoaderStrategy cartLoaderStrategy;
    private final CheckoutCustomerStrategy checkoutCustomerStrategy;
    private final CustomerAccountService customerAccountService;
    private final CommerceCheckoutService commerceCheckoutService;
    private final UserFacade userFacade;
    private final CommonI18NService commonI18NService;
    private final BaseStoreService baseStoreService;
    private final CartService cartService;
    private final PaymentModeService paymentModeService;

    public NovalnetOrderFacade(
            final NovalnetOrderDao novalnetOrderDao,
            final ModelService modelService,
            final CartFacade cartFacade,
            final CartLoaderStrategy cartLoaderStrategy,
            final CheckoutCustomerStrategy checkoutCustomerStrategy,
            final CustomerAccountService customerAccountService,
            final CommerceCheckoutService commerceCheckoutService,
            final DefaultB2BCheckoutFacade checkoutFacade,   
            final UserFacade userFacade,
            final CommonI18NService commonI18NService,
            final BaseStoreService baseStoreService,
            final PaymentModeService paymentModeService,
            final CartService cartService) {

        this.novalnetOrderDao = novalnetOrderDao;
        this.modelService = modelService;
        this.cartFacade = cartFacade;
        this.checkoutFacade = checkoutFacade;
        this.cartLoaderStrategy = cartLoaderStrategy;
        this.checkoutCustomerStrategy = checkoutCustomerStrategy;
        this.customerAccountService = customerAccountService;
        this.commerceCheckoutService = commerceCheckoutService;
        this.userFacade = userFacade;
        this.commonI18NService = commonI18NService;
        this.baseStoreService = baseStoreService;
        this.cartService = cartService;
        this.paymentModeService = paymentModeService;
    }

    public boolean hasCheckoutCart() {
        return cartFacade.hasSessionCart();
    }

    public CartModel getCart() {
        return hasCheckoutCart() ? cartService.getSessionCart() : null;
    }

    public CartData loadCart(final String cartId) {
        requireNotBlank(cartId, "cartId");
        cartLoaderStrategy.loadCart(cartId);
        return cartFacade.getSessionCart();
    }

    public CustomerModel getCurrentUserForCheckout() {
        return checkoutCustomerStrategy.getCurrentUserForCheckout();
    }

    protected CommerceCheckoutParameter createCheckoutParameter(
            final CartModel cart, final boolean enableHooks) {

        final CommerceCheckoutParameter parameter = new CommerceCheckoutParameter();
        parameter.setCart(cart);
        parameter.setEnableHooks(enableHooks);
        return parameter;
    }

    public BaseStoreModel getBaseStoreModel() {
        return baseStoreService.getCurrentBaseStore();
    }

    public PaymentTransactionEntryModel createTransactionEntry(
            final String requestId,
            final CartModel cartModel,
            final int amount,
            final String comments,
            final String currencyIso) {

        requireNotBlank(requestId, "requestId");
        requireNotBlank(currencyIso, "currencyIso");

        final PaymentTransactionEntryModel entry =
                modelService.create(PaymentTransactionEntryModel.class);

        entry.setRequestId(requestId);
        entry.setType(PaymentTransactionType.AUTHORIZATION);
        entry.setTransactionStatus(TransactionStatus.ACCEPTED.name());
        entry.setTransactionStatusDetails(comments);
        entry.setCode(cartModel.getCode());
        entry.setCurrency(commonI18NService.getCurrency(currencyIso));
        entry.setAmount(BigDecimal.valueOf(amount).divide(BigDecimal.valueOf(100)));
        entry.setTime(new Date());

        return entry;
    }

    public void updateOrderStatus(
            final String orderCode,
            final NovalnetPaymentInfoModel paymentInfo,
            OrderModel order) {

        requireNotBlank(orderCode, "orderCode");
        requireNotNull(paymentInfo, "paymentInfo");

        final NovalnetPaymentGatewayStatus status =
                NovalnetPaymentGatewayStatus
                        .fromValue(paymentInfo.getPaymentGatewayStatus())
                        .orElseThrow(() -> new RequestParameterException(
                                "Invalid payment gateway status",
                                RequestParameterException.INVALID,
                                "paymentGatewayStatus"));

        switch (status) {
            case PENDING:
                order.setStatus(OrderStatus.PAYMENT_NOT_CAPTURED);
                order.setPaymentStatus(PaymentStatus.NOTPAID);
                break;

            case ON_HOLD:
                order.setStatus(OrderStatus.PAYMENT_AUTHORIZED);
                order.setPaymentStatus(PaymentStatus.NOTPAID);
                break;

            case CONFIRMED:
                order.setStatus(OrderStatus.COMPLETED);
                order.setPaymentStatus(PaymentStatus.PAID);
                break;

            case FAILURE:
            case DEACTIVATED:
                order.setStatus(OrderStatus.CANCELLED);
                order.setPaymentStatus(PaymentStatus.NOTPAID);
                break;
        }

        modelService.save(order);
    }

    public void updateCancelStatus(final String orderCode) {
        requireNotBlank(orderCode, "orderCode");

        final OrderModel order = novalnetOrderDao.findOrderByCode(orderCode);
        order.setStatus(OrderStatus.CANCELLED);
        modelService.save(order);
    }

    public void updatePartPaidStatus(final String orderCode) {
        requireNotBlank(orderCode, "orderCode");

        final OrderModel order = novalnetOrderDao.findOrderByCode(orderCode);
        order.setPaymentStatus(PaymentStatus.PARTPAID);
        modelService.save(order);
    }

    public void updateCallbackComments(
            final String comments,
            final String orderCode,
            final String transactionStatus) {

        requireNotBlank(orderCode, "orderCode");
        requireNotBlank(transactionStatus, "transactionStatus");

        final NovalnetPaymentInfoModel paymentInfo =
                novalnetOrderDao.getLatestNovalnetPaymentInfo(orderCode);

        final String existing =
                paymentInfo.getOrderHistoryNotes() == null
                        ? ""
                        : paymentInfo.getOrderHistoryNotes();

        paymentInfo.setOrderHistoryNotes(existing + "<br>" + comments);
        paymentInfo.setPaymentGatewayStatus(transactionStatus);

        final OrderModel order =
                novalnetOrderDao.findOrderByCode(orderCode);

        final OrderHistoryEntryModel entry =
                modelService.create(OrderHistoryEntryModel.class);

        entry.setOrder(order);
        entry.setTimestamp(new Date());
        entry.setDescription(comments);

        modelService.saveAll(paymentInfo, entry);
    }

    public void updateCallbackInfo(
            final long callbackTid,
            final String originalTid,
            final int paidAmount) {

        requireNotBlank(originalTid, "originalTid");

        final NovalnetCallbackInfoModel callback =
                novalnetOrderDao.findCallbackInfoByOriginalTid(originalTid);

        callback.setCallbackTid(callbackTid);
        callback.setPaidAmount(paidAmount);

        modelService.save(callback);
    }

    public AddressModel getAddress(final String addressPk) {
        if (StringUtils.isBlank(addressPk) || "0".equals(addressPk)) {
            return null;
        }
        return modelService.get(PK.parse(addressPk));
    }

    private void requireNotBlank(final String value, final String field) {
        if (StringUtils.isBlank(value)) {
            throw new RequestParameterException(
                    field + " must not be empty",
                    RequestParameterException.INVALID,
                    field);
        }
    }

    private void requireNotNull(final Object value, final String field) {
        if (value == null) {
            throw new RequestParameterException(
                    field + " must not be null",
                    RequestParameterException.INVALID,
                    field);
        }
    }

    protected static String sanitize(final String input) {
        return YSanitizer.sanitize(input);
    }

    public static boolean hasAgeRequirement(final String dateOfBirth) {
        try {
            final Date dob =
                    new SimpleDateFormat("yyyy-MM-dd").parse(dateOfBirth);

            final long ageMillis =
                    System.currentTimeMillis() - dob.getTime();

            final long years =
                    ageMillis /
                            (DAYS_IN_YEAR * HOURS_IN_DAY *
                             MINUTES_IN_HOUR * SECONDS_IN_MINUTE * 1000L);

            return years >= AGE_REQUIREMENT;
        } catch (ParseException e) {
            return false;
        }
    }
    
    public void updatePaymentInfo(
            final String orderCode,
            final String paymentGatewayStatus) {

        requireNotBlank(orderCode, "orderCode");
        requireNotBlank(paymentGatewayStatus, "paymentGatewayStatus");

        final NovalnetPaymentInfoModel paymentInfo =
                novalnetOrderDao.getLatestNovalnetPaymentInfo(orderCode);

        paymentInfo.setPaymentGatewayStatus(paymentGatewayStatus);

        modelService.save(paymentInfo);
    }
    
    /**
     * Returns the default shipping address for the given customer.
     *
     * @param shippingAddressPk
     *           the customer's unique ID
     * @return the default shipping address of the user
     */
    public AddressModel getShippingAddress(final String shippingAddressPk)
    {
        return "0".equals(shippingAddressPk) ? null : (AddressModel) modelService.get(PK.parse(shippingAddressPk));
    }
    
    public OrderData createOrderFromNovalnetResponse(
            final JSONObject responseJson, String cartId)
            throws InvalidCartException {

        final JSONObject transaction =
                responseJson.getJSONObject("transaction");
        final JSONObject customJsonObject =
                responseJson.getJSONObject("custom");

        final CartData cartData = loadCart(cartId);
        final CartModel cart = getCart();

        final String currencyIso =
                cartData.getTotalPriceWithTax().getCurrencyIso();

        final int orderAmountInCents =
                cartData.getTotalPriceWithTax()
                        .getValue()
                        .multiply(BigDecimal.valueOf(100))
                        .intValue();

        final String customerEmail =
                getCurrentUserForCheckout().getUid();

        final AddressModel billingAddress =
                getBillingAddress(responseJson, cart);

        final NovalnetPaymentInfoModel paymentInfo =
                modelService.create(NovalnetPaymentInfoModel.class);

        paymentInfo.setBillingAddress(billingAddress);
        paymentInfo.setPaymentEmailAddress(customerEmail);
        paymentInfo.setPaymentProvider(
                transaction.getString("payment_type"));
        paymentInfo.setPaymentInfo(transaction.get("tid").toString());
        paymentInfo.setPaymentGatewayStatus(
                transaction.getString("status"));
        paymentInfo.setSaved(Boolean.FALSE);
        paymentInfo.setDuplicate(Boolean.FALSE);
        paymentInfo.setUser(getCurrentUserForCheckout());
        paymentInfo.setOrderHistoryNotes(buildOrderHistoryNotes(transaction, cartData, customJsonObject.get("inputval2").toString()));
        paymentInfo.setCode("");
        cart.setPaymentInfo(paymentInfo);

        final PaymentTransactionEntryModel entry =
                createTransactionEntry(
                        transaction.get("tid").toString(),
                        cart,
                        orderAmountInCents,
                        "TID " + transaction.get("tid").toString(),
                        currencyIso);

        final PaymentTransactionModel transactionModel =
                modelService.create(PaymentTransactionModel.class);

        transactionModel.setOrder(cart);
        transactionModel.setRequestId(transaction.get("tid").toString());
        transactionModel.setPaymentProvider(
                transaction.getString("payment_type"));
        transactionModel.setInfo(paymentInfo);
        transactionModel.setEntries(List.of(entry));

        cart.setPaymentTransactions(List.of(transactionModel));

        modelService.saveAll(paymentInfo, cart, transactionModel, entry);

        final OrderData orderData = checkoutFacade.placeOrder();
        final OrderModel order =
                novalnetOrderDao.findOrderByCode(orderData.getCode());

        paymentInfo.setCode(order.getCode());
        order.setPaymentInfo(paymentInfo);
        order.setPaymentMode(getNovalnetPaymentMode());
        
        order.setStatusInfo(
        getLabel("novalnet.paymentname") + 
        " : " + customJsonObject.get("inputval2").toString() +
        ", " +
        getLabel("novalnet.transactionID") +
        " " + 
        transaction.get("tid").toString());
        
        modelService.saveAll(paymentInfo);

        createOrderHistory(order, transaction);
        createCallbackInfo(order, transaction, orderAmountInCents);
        
        updateOrderStatus(order.getCode(), paymentInfo, order);

        return orderData;
    }
    
    private String buildOrderHistoryNotes(
        final JSONObject transaction,
        final CartData cartData,
        final String paymentName)
    {
        final StringBuilder notes = new StringBuilder(256);

        appendPaymentHeader(notes, transaction, paymentName);
        appendTestMode(notes, transaction);
        appendBankDetails(notes, transaction, cartData);
        appendPartnerPaymentReference(notes, transaction, cartData);
        
        return notes.toString();
    }
    
    private void appendPaymentHeader(
        final StringBuilder notes,
        final JSONObject transaction,
        final String paymentName)
    {
        notes.append(getLabel("novalnet.paymentname"))
             .append(" : ")
             .append(paymentName)
             .append(BR)
             .append(getLabel("novalnet.transactionID"))
             .append(" ")
             .append(transaction.optString("tid"))
             .append(BR);
        
        if ("0".equals(transaction.optString("amount"))) {
			notes.append(getLabel("novalnet.zeroAmountTransactionText"))
                 .append(BR);
		}
    }
    
    private void appendTestMode(
        final StringBuilder notes,
        final JSONObject transaction)
    {
        if ("1".equals(transaction.optString("test_mode"))) {
            notes.append(getLabel("novalnet.testOrderText"))
                 .append(BR);
        }
    }
    
    private void appendBankDetails(
            final StringBuilder notes,
            final JSONObject transaction,
            final CartData cartData)
    {
        final JSONObject bankDetails = transaction.optJSONObject("bank_details");
        if (bankDetails == null) {
            return;
        }

        final String amount = cartData.getTotalPriceWithTax().getFormattedValue();
        final String status = transaction.optString("status");

        
        if(!"75".equals(transaction.optString("status_code"))) {
			
			notes.append(BR)
             .append(String.format(
                     getLabel("novalnet.bankDetailsComments1"), amount));

			if (transaction.has("due_date") && !STATUS_ON_HOLD.equals(status)) {
				notes.append(" ")
					 .append(String.format(
							 getLabel("novalnet.bankDetailsComments2"),
							 transaction.optString("due_date")));
			}

			appendLabelValue(notes, "novalnet.bankDetailsAccountHolder",
					bankDetails.optString("account_holder"));
					
			appendLabelValue(notes, "novalnet.bankDetailsIban",
					bankDetails.optString("iban"));
					
			appendLabelValue(notes, "novalnet.bankDetailsBic",
					bankDetails.optString("bic"));

			appendLabelValue(notes, "novalnet.bankDetailsBank",
					bankDetails.optString("bank_name"));

			appendLabelValue(notes, "novalnet.bankPlace",
					bankDetails.optString("bank_place"));

			notes.append(BR)
				 .append(getLabel("novalnet.bankDetailspaymentRefernceMulti"))
				 .append(BR)
				 .append(getLabel("novalnet.bankDetailsPaymentReference"))
				 .append(" : TID ")
				 .append(transaction.optString("tid"))
				 .append(BR);
				 
			if (bankDetails.has("qr_image") && 
				bankDetails.optString("qr_image") != null &&
				"100".equals(transaction.optString("status_code")) ) {
				notes.append(getLabel("novalnet.qrCodeComments"))
				 .append(BR)
				 .append(BR)
				 .append("<img alt='nn_qr_code' src='"+bankDetails.optString("qr_image")+"'>")
				 .append(BR);
			}
		} else {
			notes.append(BR)
             .append(getLabel("novalnet.guaranteePendingNote"));
		}
    }

    private void appendPartnerPaymentReference(
            final StringBuilder notes,
            final JSONObject transaction,
            final CartData cartData)
    {
        if (!transaction.has("partner_payment_reference")) {
            return;
        }

        notes.append(BR)
             .append(getLabel("novalnet.multibancocomments1"))
             .append(" ")
             .append(cartData.getTotalPriceWithTax().getFormattedValue())
             .append(" ")
             .append(getLabel("novalnet.multibancocomments2"))
             .append(BR)
             .append(getLabel("novalnet.bankDetailsPaymentReference"))
             .append(" : ")
             .append(transaction.optString("partner_payment_reference"));
    }

    private void appendLabelValue(
            final StringBuilder sb,
            final String labelKey,
            final String value)
    {
        if (StringUtils.isNotBlank(value)) {
            sb.append(BR)
              .append(getLabel(labelKey))
              .append(" ")
              .append(value);
        }
    }

    public String getLabel(final String key)
    {
        return Localization.getLocalizedString(key);
    }

    
    protected AddressModel getBillingAddress(
            final JSONObject responseJson,
            final CartModel owner) {

        if (responseJson == null || !responseJson.has("customer")) {
            throw new IllegalArgumentException(
                    "Invalid Novalnet response: missing customer block");
        }

        final JSONObject customerJson = responseJson.getJSONObject("customer");

        if (!customerJson.has("billing")) {
            throw new IllegalArgumentException(
                    "Invalid Novalnet response: missing billing block");
        }

        final JSONObject billingJson = customerJson.getJSONObject("billing");

        final AddressModel billingAddress =
                modelService.create(AddressModel.class);

        billingAddress.setOwner(owner);

        // --- Customer name ---
        billingAddress.setFirstname(
                customerJson.optString("first_name", "")
        );
        billingAddress.setLastname(
                customerJson.optString("last_name", "")
        );

        // --- Address lines ---
        billingAddress.setLine1(
                billingJson.optString("street", "")
        );
        billingAddress.setLine2("");

        // --- City & Postal code ---
        billingAddress.setTown(
                billingJson.optString("city", "")
        );
        billingAddress.setPostalcode(
                billingJson.optString("zip", "")
        );

        // --- Country ---
        final String countryIso =
                billingJson.optString("country_code", null);

        if (countryIso != null) {
            billingAddress.setCountry(
                    commonI18NService.getCountry(countryIso)
            );
        }
    
        billingAddress.setEmail(
                customerJson.optString("email", "")
        );
        
        modelService.save(billingAddress);

        return billingAddress;
    }

    
    protected void createOrderHistory(
            final OrderModel order,
            final JSONObject transaction) {

        final OrderHistoryEntryModel history =
                modelService.create(OrderHistoryEntryModel.class);

        history.setOrder(order);
        history.setTimestamp(new Date());
        history.setDescription(
                "Novalnet TID " + transaction.get("tid").toString());

        modelService.save(history);
    }
    
    protected void createCallbackInfo(
            final OrderModel order,
            final JSONObject transaction,
            final int orderAmountInCents) {

        final NovalnetCallbackInfoModel callbackInfo =
                modelService.create(NovalnetCallbackInfoModel.class);

        final long tid = Long.parseLong(transaction.get("tid").toString());

        callbackInfo.setOrderNo(order.getCode());
        callbackInfo.setPaymentType(
                transaction.getString("payment_type"));
        callbackInfo.setOrginalTid(tid);
        callbackInfo.setCallbackTid(tid);
        callbackInfo.setOrderAmount(orderAmountInCents);
        callbackInfo.setPaidAmount(
                "PENDING".equals(transaction.getString("status"))
                        ? 0
                        : orderAmountInCents);

        modelService.save(callbackInfo);
    }

    public PaymentModeModel getNovalnetPaymentMode() {
        return paymentModeService.getPaymentModeForCode("novalnet");
    }
    
    public String getLanguage() {
        final LanguageModel language = commonI18NService.getCurrentLanguage();
        return language.getIsocode();
    }
    
    public NovalnetPaymentInfoModel getPaymentModel(final List<NovalnetPaymentInfoModel> paymentInfo) {
        final NovalnetPaymentInfoModel paymentModel = modelService.get(paymentInfo.get(0).getPk());
        return paymentModel;
    }
    
    public void setSessionLanguage(final OrderModel order)
	{
		LanguageModel language = order.getLanguage();
		commonI18NService.setCurrentLanguage(language);
	}

}

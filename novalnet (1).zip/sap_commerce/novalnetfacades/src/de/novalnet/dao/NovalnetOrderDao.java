package de.novalnet.dao;

import java.util.List;

import de.hybris.novalnet.core.model.NovalnetCallbackInfoModel;
import de.hybris.novalnet.core.model.NovalnetPaymentInfoModel;
import de.hybris.platform.core.model.order.OrderModel;

public interface NovalnetOrderDao {

    OrderModel findOrderByCode(String orderCode);

    NovalnetPaymentInfoModel getLatestNovalnetPaymentInfo(String orderCode);

    NovalnetCallbackInfoModel findCallbackInfoByOriginalTid(String transactionId);
    
    boolean isOrderCreatedForCart(String cartCode);
}

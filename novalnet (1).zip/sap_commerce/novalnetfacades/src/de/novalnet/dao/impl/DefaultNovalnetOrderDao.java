package de.novalnet.dao.impl;

import de.hybris.novalnet.core.model.NovalnetCallbackInfoModel;
import de.hybris.novalnet.core.model.NovalnetPaymentInfoModel;
import de.novalnet.dao.NovalnetOrderDao;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.servicelayer.exceptions.ModelNotFoundException;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import de.hybris.platform.servicelayer.search.SearchResult;

import javax.annotation.Resource;

public class DefaultNovalnetOrderDao implements NovalnetOrderDao {

    private final FlexibleSearchService flexibleSearchService;

    private static final String FIND_ORDER_BY_CODE =
            "SELECT {pk} FROM {Order AS o} WHERE {o.code}=?code ";

    private static final String FIND_LATEST_NOVALNET_PAYMENT_INFO =
        "SELECT {p.pk} " +
        "FROM {NovalnetPaymentInfo AS p} " +
        "WHERE {p.code} = ?code " +
        "ORDER BY {p.creationtime} DESC LIMIT 1";

    private static final String FIND_CALLBACK_INFO =
            "SELECT {pk} FROM {NovalnetCallbackInfo AS c} " +
            "WHERE {c.orginalTid}=?tid";
            
    public DefaultNovalnetOrderDao(
            final FlexibleSearchService flexibleSearchService) {
        this.flexibleSearchService = flexibleSearchService;
    }
    
    protected FlexibleSearchService getFlexibleSearchService() {
        return flexibleSearchService;
    }

    @Override
    public OrderModel findOrderByCode(final String orderCode) {
        final FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_ORDER_BY_CODE);
        query.addQueryParameter("code", orderCode);

        SearchResult<OrderModel> result = flexibleSearchService.search(query);
		return result.getResult().isEmpty() ? null : result.getResult().get(0);
    }

    @Override
    public NovalnetPaymentInfoModel getLatestNovalnetPaymentInfo(final String orderCode)
	{
		final FlexibleSearchQuery query =
        new FlexibleSearchQuery(FIND_LATEST_NOVALNET_PAYMENT_INFO);

		query.addQueryParameter("code", orderCode);
		return flexibleSearchService.searchUnique(query);
	}

    @Override
    public NovalnetCallbackInfoModel findCallbackInfoByOriginalTid(final String transactionId) {
        final FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_CALLBACK_INFO);
        query.addQueryParameter("tid", transactionId);

        return flexibleSearchService.searchUnique(query);
    }
    
    @Override
    public boolean isOrderCreatedForCart(String cartCode) {
		String query = "SELECT {pk} FROM {Order AS o} WHERE {o.originalVersion}=?cartCode";

		FlexibleSearchQuery fsq = new FlexibleSearchQuery(query);
		fsq.addQueryParameter("cartCode", cartCode);

		SearchResult<OrderModel> result = flexibleSearchService.search(fsq);

		return !result.getResult().isEmpty();
	}
}

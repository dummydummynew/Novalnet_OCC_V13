package de.novalnet.callback;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import de.novalnet.order.NovalnetOrderFacade;
import de.novalnet.dao.NovalnetOrderDao;
import de.novalnet.enums.NovalnetPaymentGatewayStatus;
import de.novalnet.beans.*;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.novalnet.core.model.NovalnetCallbackInfoModel;
import de.hybris.novalnet.core.model.NovalnetPaymentInfoModel;
import de.hybris.platform.store.BaseStoreModel;
import de.hybris.platform.servicelayer.exceptions.SystemException;

import java.math.BigDecimal;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

import java.util.Date;
import java.util.Calendar;
import java.util.Set;

import java.text.SimpleDateFormat;

public class NovalnetCallbackFacade {

    private static final Logger LOG =
            Logger.getLogger(NovalnetCallbackFacade.class);

    private final NovalnetOrderFacade orderFacade;
    private final NovalnetOrderDao orderDao;
    private String currentDate;
    private static final Set<String> UPDATE_WITH_DATE_AMOUNT =
        Set.of("DUE_DATE", "AMOUNT_DUE_DATE");        
    private static final Set<String> CREDIT_PAYMENT_TYPES = Set.of(
            "INVOICE_CREDIT",
            "CASHPAYMENT_CREDIT",
            "MULTIBANCO_CREDIT"
    );

    public NovalnetCallbackFacade(
            final NovalnetOrderFacade orderFacade,
            final NovalnetOrderDao orderDao) {
        this.orderFacade = orderFacade;
        this.orderDao = orderDao;
    }

    public String processCallback(
            final NnCallbackRequestData request,
            final HttpServletRequest httpRequest) {

        validateCallbackIp(httpRequest);
        validateMandatoryParams(request);
        validateCallbackChecksum(request);
        currentDate = getCurrentDate();

        final String eventType = request.getEvent().getType();

        logEvent("CALLBACK_RECEIVED", request);

        switch (eventType) {
            case "TRANSACTION_CAPTURE":
                return handleTransactionCapture(request);

            case "TRANSACTION_CANCEL":
                return handleTransactionCancel(request);

            case "TRANSACTION_UPDATE":
                return handleTransactionUpdate(request);

            case "PAYMENT":
                return handlePayment(request);

            case "CREDIT":
                return handleCredit(request);

            case "TRANSACTION_REFUND":
            case "CHARGEBACK":
                return handleRefund(request);

            case "PAYMENT_REMINDER_1":
            case "PAYMENT_REMINDER_2":
                return handleReminder(request);

            case "SUBMISSION_TO_COLLECTION_AGENCY":
                return handleCollection(request);

            default:
                return "Unsupported callback event type: " + eventType;
        }
    }
    
    public String handleTransactionCapture(final NnCallbackRequestData request) {

        final NnCallbackTransactionData txn = request.getTransaction();
        
        final String orderCode = request.getTransaction().getOrder_no();
        
        final OrderModel order = orderDao.findOrderByCode(orderCode);
        orderFacade.setSessionLanguage(order);
        
        orderFacade.setSessionLanguage(order);

        orderFacade.updatePaymentInfo(orderCode, txn.getStatus());
        orderFacade.updateOrderStatus(
                orderCode,
                orderDao.getLatestNovalnetPaymentInfo(orderCode),
                order);
                
        final String paymentType = txn.getPayment_type();

        final boolean isInvoice =
                "GUARANTEED_INVOICE".equals(paymentType)
             || "INVOICE".equals(paymentType);

        final String msg = isInvoice
                ? String.format(
                      orderFacade.getLabel("novalnet.callbackCaptureUpdateText"),
                      txn.getTid(),
                      txn.getDue_date())
                : String.format(
                      orderFacade.getLabel("novalnet.callbackConfirmUpdateText"),
                      currentDate);

        orderFacade.updateCallbackComments(msg, orderCode, txn.getStatus());

        logEvent("TRANSACTION_CAPTURE", request);
        return msg;
    }

    public String handleTransactionCancel(final NnCallbackRequestData request) {

        final String orderCode =
                orderDao.findCallbackInfoByOriginalTid(
                        request.getTransaction().getTid())
                        .getOrderNo();

        orderFacade.updateCancelStatus(orderCode);
        
        final OrderModel order = orderDao.findOrderByCode(orderCode);
        orderFacade.setSessionLanguage(order);

        final String msg = String.format(
                    orderFacade.getLabel("novalnet.callbackCancelUpdateText"),
                    currentDate.toString()
        );
                
        orderFacade.updateCallbackComments(msg, orderCode,
                request.getTransaction().getStatus());

        logEvent("TRANSACTION_CANCEL", request);
        return msg;
    }

    public String handleTransactionUpdate(final NnCallbackRequestData request) {

        final NnCallbackTransactionData transaction = request.getTransaction();

        final String tid = transaction.getTid();
        final String status = transaction.getStatus();
        final String updateType = transaction.getUpdate_type();

        final String orderCode =
                orderDao.findCallbackInfoByOriginalTid(tid)
                        .getOrderNo();

        final NovalnetPaymentInfoModel paymentInfo =
                orderDao.getLatestNovalnetPaymentInfo(orderCode);

        orderFacade.updatePaymentInfo(orderCode, status);

        String msg = "";

        if (UPDATE_WITH_DATE_AMOUNT.contains(updateType)) {

            msg = String.format(
                    orderFacade.getLabel("novalnet.callbackAmountDueDateUpdateText"),
                    tid,
                    formatAmount(transaction.getAmount()),
                    transaction.getCurrency(),
                    transaction.getDue_date()
            );

        } else if ("AMOUNT".equals(updateType)) {

            msg = String.format(
                    orderFacade.getLabel("novalnet.callbackAmountUpdateText"),
                    tid,
                    formatAmount(transaction.getAmount()),
                    transaction.getCurrency(),
                    currentDate.toString()
            );

        } else if ("STATUS".equals(updateType)) {

            switch (status) {

                case "DEACTIVATED":
                    msg = String.format(
                            orderFacade.getLabel("novalnet.callbackCancelUpdateText"),
                            currentDate.toString()
                    );
                    break;

                case "ON_HOLD":
                    msg = String.format(
                            orderFacade.getLabel("novalnet.callbackOnhodUpdateText"),
                            tid,
                            currentDate.toString()
                    );
                    break;

                case "CONFIRMED":
                    msg = String.format(
                            orderFacade.getLabel("novalnet.callbackConfirmUpdateText"),
                            currentDate.toString()
                    );
                    break;

                default:
                    msg = String.format(
                            "Transaction status updated for TID %s to %s",
                            tid,
                            status
                    );
                    break;
            }
            
            final OrderModel order =
                orderDao.findOrderByCode(orderCode);
                
			orderFacade.setSessionLanguage(order);

            orderFacade.updateOrderStatus(orderCode, paymentInfo, order);
        }

        orderFacade.updateCallbackComments(msg, orderCode, status);

        logEvent("TRANSACTION_UPDATE", request);

        return msg;
    }


    public String handlePayment(final NnCallbackRequestData request) {
        
        final NnCallbackTransactionData txn = request.getTransaction();
        
        final String status = txn.getStatus();
        
        final String orderCode = txn.getOrder_no();
        
        final OrderModel order = orderDao.findOrderByCode(orderCode);
        
        final NovalnetPaymentInfoModel paymentInfo =
                orderDao.getLatestNovalnetPaymentInfo(orderCode);
        
        orderFacade.updatePaymentInfo(orderCode, status);
        
        orderFacade.updateOrderStatus(orderCode, paymentInfo, order);
        
        logEvent("PAYMENT", request);

        return "Novalnet webhook script executed. Status updated for initial transaction";
    }

    public String handleCredit(final NnCallbackRequestData request) {

        final NnCallbackTransactionData txn = request.getTransaction();
        final String parentTid = request.getEvent().getParent_tid();

        final NovalnetCallbackInfoModel ref =
                orderDao.findCallbackInfoByOriginalTid(parentTid);

        final String orderCode = ref.getOrderNo();

        final NovalnetPaymentInfoModel paymentInfo =
                orderDao.getLatestNovalnetPaymentInfo(orderCode);
                
        final OrderModel order = orderDao.findOrderByCode(orderCode);
        orderFacade.setSessionLanguage(order);

        // Process credit only for valid payment types
        if (CREDIT_PAYMENT_TYPES.contains(txn.getPayment_type())) {

            int currentPaid = Math.toIntExact(ref.getPaidAmount());
            int receivedAmount = Integer.parseInt(txn.getAmount());

            int totalPaid = currentPaid + receivedAmount;

            orderFacade.updateCallbackInfo(
                    Long.parseLong(txn.getTid()),
                    parentTid,
                    totalPaid
            );

            // Update order status if fully paid
            if (totalPaid >= ref.getOrderAmount()) {
                orderFacade.updateOrderStatus(orderCode, paymentInfo, order);
            }
        }

        String msg = buildCreditMessage(txn, parentTid);

        orderFacade.updateCallbackComments(msg, orderCode, txn.getStatus());

        logEvent("CREDIT", request);

        return msg;
    }

    private String buildCreditMessage(NnCallbackTransactionData txn, String parentTid) {

        return String.format(
                orderFacade.getLabel("novalnet.callbackCreditText"),
                parentTid,
                formatAmount(txn.getAmount()),
                txn.getCurrency(),
                getCurrentDate(),
                txn.getTid()
        );
    }

    public BigDecimal formatAmount(String amount) {

        return new BigDecimal(amount)
                .movePointLeft(2);
    }

    public String handleRefund(final NnCallbackRequestData request) {

        final NnCallbackTransactionData transaction = request.getTransaction();
        final NnCallbackEventData event = request.getEvent();

        // Resolve original TID safely
        final String originalTid = (event != null && event.getParent_tid() != null)
                ? event.getParent_tid()
                : transaction.getTid();

        final String orderCode = orderDao
                .findCallbackInfoByOriginalTid(originalTid)
                .getOrderNo();
                
        final OrderModel order = orderDao.findOrderByCode(orderCode);
        orderFacade.setSessionLanguage(order);

        final NnCallbackRefundData refund = transaction.getRefund();

        final String transactionStatus = transaction.getStatus();
        final String eventType = event != null ? event.getType() : null;
        final String currency = transaction.getCurrency();

        String msg;

        // Handle Refund
        if ("TRANSACTION_REFUND".equals(eventType)) {

            if (refund != null && refund.getTid() != null) {

                final String newTid =
                        event != null && event.getTid() != null
                                ? event.getTid()
                                : refund.getTid();

                msg = String.format(
                        orderFacade.getLabel("novalnet.callbackRefundText"),
                        originalTid,
                        formatAmount(refund.getAmount()),
                        currency,
                        newTid
                );

            } else {

                msg = String.format(
                        orderFacade.getLabel("novalnet.callbackRefundTextOrgTid"),
                        transaction.getTid(),
                        formatAmount(refund != null ? refund.getAmount() : null),
                        currency
                );
            }

        }
        // Handle Chargeback
        else {

            msg = String.format(
                    orderFacade.getLabel("novalnet.callbackChargebackText"),
                    originalTid,
                    formatAmount(transaction.getAmount()),
                    currency,
                    getCurrentDate(),
                    transaction.getTid()
            );
        }

        // Update order status
        if ("DEACTIVATED".equals(transactionStatus)) {
            orderFacade.updateCancelStatus(orderCode);
        }

        // Update comments
        orderFacade.updateCallbackComments(
                msg,
                orderCode,
                transactionStatus
        );

        logEvent("REFUND", request);

        return msg;
    }


    public String handleReminder(final NnCallbackRequestData request) {

        final NnCallbackTransactionData transaction = request.getTransaction();
        final NnCallbackEventData event = request.getEvent();

        final String tid = transaction.getTid();

        final String orderCode =
                orderDao.findCallbackInfoByOriginalTid(tid)
                        .getOrderNo();
                        
        final OrderModel order = orderDao.findOrderByCode(orderCode);
        orderFacade.setSessionLanguage(order);

        final String eventType = event != null ? event.getType() : null;

        String count = "PAYMENT_REMINDER_1".equals(eventType) ? "1" : "2";

        String msg = String.format(
                orderFacade.getLabel("novalnet.callbackReminderText"),
                count
        );

        orderFacade.updateCallbackComments(
            msg,
            orderCode,
            transaction.getStatus()
        );

        logEvent("REMINDER", request);

        return msg;
    }


    public String handleCollection(final NnCallbackRequestData request) {

        final NnCallbackTransactionData transaction = request.getTransaction();
        final NnCallbackCollectionData collection = request.getCollection();

        final String tid = transaction.getTid();

        final String orderCode =
                orderDao.findCallbackInfoByOriginalTid(tid)
                        .getOrderNo();
                        
        final OrderModel order = orderDao.findOrderByCode(orderCode);
        orderFacade.setSessionLanguage(order);

        String label = orderFacade.getLabel("novalnet.callbackCollectionText");

        StringBuilder msgBuilder = new StringBuilder(label);

        if (collection != null && collection.getReference() != null) {

            String reference = collection.getReference();
            String refLabel = orderFacade.getLabel("novalnet.callbackCollectionReferenceText");

            msgBuilder.append(' ')
                      .append(String.format(refLabel, reference));
        }

        String msg = msgBuilder.toString();

        orderFacade.updateCallbackComments(
                msg,
                orderCode,
                transaction.getStatus()
        );

        logEvent("COLLECTION", request);

        return msg;
    }

    private void validateCallbackIp(final HttpServletRequest request) {

        final BaseStoreModel baseStore = orderFacade.getBaseStoreModel();

        final boolean testMode = Boolean.TRUE.equals(
                baseStore.getNovalnetVendorscriptTestMode());

        final String callerIp = extractClientIp(request);
        final String novalnetIp = resolveNovalnetIp();

        logStructured(
                "IP_VALIDATION",
                "callerIp", callerIp,
                "novalnetIp", novalnetIp,
                "testMode", String.valueOf(testMode)
        );

        if (!testMode && !novalnetIp.equals(callerIp)) {
            throw new IllegalStateException(
                    "Unauthorized callback source IP: " + callerIp);
        }
    }
    
    private String extractClientIp(final HttpServletRequest request) {

        final String forwardedFor = request.getHeader("X-Forwarded-For");

        if (forwardedFor != null && !forwardedFor.isEmpty()) {
            return forwardedFor.split(",")[0].trim();
        }

        return request.getRemoteAddr();
    }

    private String resolveNovalnetIp() {
        try {
            return InetAddress.getByName("pay-nn.de").getHostAddress();
        } catch (Exception ex) {
            throw new IllegalStateException(
                    "Failed to resolve Novalnet host IP", ex);
        }
    }

    private void validateMandatoryParams(final NnCallbackRequestData request) {
        if (request.getEvent() == null ||
            request.getTransaction() == null ||
            request.getResult() == null) {
            throw new SystemException("Mandatory callback parameters missing");
        }
    }

    private void validateCallbackChecksum(final NnCallbackRequestData request) {

        final BaseStoreModel baseStore = orderFacade.getBaseStoreModel();
        final String accessKey = baseStore.getNovalnetPaymentAccessKey();

        if (accessKey == null || accessKey.isEmpty()) {
            throw new IllegalStateException(
                    "Novalnet payment access key is not configured");
        }

        final String calculatedChecksum =
                generateChecksum(request, accessKey);

        final String receivedChecksum =
                request.getEvent().getChecksum();

        logStructured(
                "CHECKSUM_VALIDATION",
                "received", receivedChecksum,
                "calculated", calculatedChecksum
        );

        if (!calculatedChecksum.equals(receivedChecksum)) {
            throw new IllegalStateException(
                    "Checksum validation failed. Callback payload may be tampered");
        }
    }
    
    private String generateChecksum(
            final NnCallbackRequestData request,
            final String accessKey) {

        final NnCallbackEventData event = request.getEvent();
        final NnCallbackTransactionData txn = request.getTransaction();
        final NnCallbackResultData result = request.getResult();

        final StringBuilder token = new StringBuilder()
                .append(event.getTid())
                .append(event.getType())
                .append(result.getStatus());

        if (txn.getAmount() != null) {
            token.append(txn.getAmount());
        }
        if (txn.getCurrency() != null) {
            token.append(txn.getCurrency());
        }

        token.append(new StringBuilder(accessKey.trim()).reverse());

        try {
            final MessageDigest digest = MessageDigest.getInstance("SHA-256");
            final byte[] hash =
                    digest.digest(token.toString().getBytes(StandardCharsets.UTF_8));

            return toHex(hash);

        } catch (Exception ex) {
            throw new IllegalStateException(
                    "Failed to generate checksum", ex);
        }
    }
    
    private String toHex(final byte[] bytes) {
        final StringBuilder hex = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            hex.append(String.format("%02x", b));
        }
        return hex.toString();
    }

    /* =================================================
       Structured Logging
       ================================================= */

    private void logEvent(final String type, final NnCallbackRequestData request) {

        LOG.info(String.format(
                "{ \"event\":\"%s\", \"tid\":\"%s\", \"parentTid\":\"%s\", \"status\":\"%s\", \"timestamp\":\"%s\" }",
                type,
                request.getTransaction().getTid(),
                request.getEvent().getParent_tid(),
                request.getTransaction().getStatus(),
                new Date()
        ));
    }
    
    private void logStructured(
            final String event,
            final String... kvPairs) {

        final StringBuilder log = new StringBuilder();
        log.append("{ \"event\":\"").append(event).append("\"");

        for (int i = 0; i < kvPairs.length; i += 2) {
            log.append(", \"")
               .append(kvPairs[i])
               .append("\":\"")
               .append(kvPairs[i + 1])
               .append("\"");
        }

        log.append(" }");
        LOG.info(log.toString());
    }
    
    private String getCurrentDate() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy, HH:mm:ss");
        String formattedDueDate = formatter.format(cal.getTime());
        return formattedDueDate;
    }
}

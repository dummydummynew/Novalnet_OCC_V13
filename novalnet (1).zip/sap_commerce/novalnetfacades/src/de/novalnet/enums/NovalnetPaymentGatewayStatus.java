package de.novalnet.enums;

import java.util.Arrays;
import java.util.Optional;

public enum NovalnetPaymentGatewayStatus {

    PENDING,
    ON_HOLD,
    CONFIRMED,
    FAILURE,
    DEACTIVATED;

    public static Optional<NovalnetPaymentGatewayStatus> fromValue(final String value) {
        if (value == null) {
            return Optional.empty();
        }
        return Arrays.stream(values())
                .filter(status -> status.name().equalsIgnoreCase(value))
                .findFirst();
    }

    public boolean isPending() {
        return this == PENDING || this == ON_HOLD;
    }

    public boolean isSuccessful() {
        return this == CONFIRMED;
    }
}

package de.novalnet.checkout;

import javax.servlet.http.HttpServletRequest;

import java.math.BigDecimal;
import java.math.RoundingMode;

import java.text.SimpleDateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import java.net.HttpURLConnection;
import java.net.URL;

import java.nio.charset.StandardCharsets;

import java.util.Base64;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.List;
import java.util.Calendar;
import java.util.Date;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import de.hybris.novalnet.core.model.NovalnetCallbackInfoModel;
import de.hybris.novalnet.core.model.NovalnetPaymentInfoModel;
import de.hybris.novalnet.core.model.NovalnetPaymentModeModel;

import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.core.model.user.AddressModel;
import de.hybris.platform.core.model.order.OrderModel;

import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.b2b.model.B2BCustomerModel;
import de.hybris.platform.b2b.model.B2BUnitModel;

import de.hybris.platform.core.model.order.payment.PaymentModeModel;

import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.user.data.AddressData;

import de.hybris.platform.order.InvalidCartException;
import de.hybris.platform.store.BaseStoreModel;

import de.novalnet.beans.*;
import de.novalnet.dao.NovalnetOrderDao;
import de.novalnet.order.NovalnetOrderFacade;

/**
 * Facade handling Novalnet checkout & payment orchestration.
 */
public class NovalnetCheckoutFacade {

    private static final Logger LOG =
            Logger.getLogger(NovalnetCheckoutFacade.class);

    private static final String PAY_URL =
            "https://payport.novalnet.de/v2/payment";
    private static final String AUTHORIZE_URL =
            "https://payport.novalnet.de/v2/authorize";
    private static final String TRANSACTION_DETAILS_URL =
            "https://payport.novalnet.de/v2/transaction/details";
    private static final String DATE_FORMAT = "yyyy-MM-dd";

    private final NovalnetOrderFacade orderFacade;
    private final NovalnetOrderDao orderDao;

    private final Gson gson = new GsonBuilder().create();

    public NovalnetCheckoutFacade(
            final NovalnetOrderFacade orderFacade,
            final NovalnetOrderDao orderDao) {

        this.orderFacade = orderFacade;
        this.orderDao = orderDao;
    }

    public NnTransactionResponseData placeTransaction(
            final NnRequestData request,
            final HttpServletRequest httpRequest) {

        final NnTransactionResponseData response =
                new NnTransactionResponseData();

        try {
            final String endpoint =
                    isAuthorize(request)
                            ? AUTHORIZE_URL
                            : PAY_URL;

            final JSONObject responseJson =
                    executeNovalnetPayment(request, endpoint, httpRequest);

            final JSONObject result =
            responseJson.optJSONObject("result");

            if (result == null) {
                throw new IllegalArgumentException(
                        "Result object missing in Novalnet response");
            }

            final String status =
                    result.optString("status");

            final String statusDescription =
                    result.optString("status_text",
                            result.optString("status_desc"));

            response.setStatus(status);
            response.setStatusDescription(statusDescription);

            if ("SUCCESS".equalsIgnoreCase(status)) {

                final JSONObject transaction =
                        responseJson.optJSONObject("transaction");

                if (transaction == null) {
                    throw new IllegalArgumentException(
                            "Transaction object missing in Novalnet response");
                }

                if (!"FAILURE".equalsIgnoreCase(transaction.optString("status"))) {
                    response.setPaymentType(
                            transaction.optString("payment_type"));
                    response.setTid(
                            transaction.get("tid").toString());
                } else {
                    response.setStatus(transaction.optString("status"));
                }
            }
            
            return response;

        } catch (Exception ex) {
            LOG.error("Place transaction failed", ex);
            response.setStatus("ERROR");
            response.setStatusDescription(
                    "Error while processing Novalnet payment");
            return response;
        }
    }

    public NnResponseData getRedirectUrl(
            final NnRequestData request,
            final HttpServletRequest httpRequest) {

        final NnResponseData response = new NnResponseData();

        try {
            
            final String endpoint =
                    isAuthorize(request)
                            ? AUTHORIZE_URL
                            : PAY_URL;
            
            final JSONObject responseJson =
                    executeNovalnetPayment(request, endpoint, httpRequest);

            final JSONObject result =
                    responseJson.optJSONObject("result");
                    
            response.setStatus(result.optString("status"));

            if (result == null ||
                !"100".equals(result.optString("status_code"))) {

                response.setStatusDescription(
                        result.optString("status_text",
                                result.optString("status_desc")));
                return response;
            }

            response.setRedirectURL(
                    result.getString("redirect_url"));
            return response;

        } catch (Exception ex) {
            LOG.error("Redirect URL generation failed", ex);
            response.setStatusDescription(
                    "Unable to get redirect URL");
            return response;
        }
    }
    
    protected JSONObject executeNovalnetPayment(
            final NnRequestData request,
            final String endpoint,
            final HttpServletRequest httpRequest) {
                
        try {

            final CartData cart = orderFacade.loadCart(request.getCartId());
            final BaseStoreModel baseStore = orderFacade.getBaseStoreModel();

            final String accessKey = baseStore.getNovalnetPaymentAccessKey();
            if (accessKey == null || accessKey.isBlank()) {
                throw new IllegalStateException(
                        "Novalnet payment access key not configured");
            }

            final int orderAmountCents = calculateOrderAmount(cart);
            final String currency = cart.getTotalPriceWithTax().getCurrencyIso();

            final String customerUid =
                    orderFacade.getCurrentUserForCheckout().getUid();
                    
            final Map<String, Object> paymentRequest =
                    buildPaymentRequest(
                            request,
                            customerUid,
                            orderAmountCents,
                            currency,
                            orderFacade.getLanguage(),
                            httpRequest);

            final String response =
                    sendRequest(endpoint,
                            gson.toJson(paymentRequest),
                            accessKey);

            return new JSONObject(response);
        } catch (Exception ex) {
            LOG.error("Error while calling Novalnet API", ex);
            throw new IllegalStateException(
                    "Failed to communicate with Novalnet", ex);
        }
    }

    public NnPaymentDetailsData getPaymentDetails(
            final String orderCode) {
                
        final NovalnetPaymentInfoModel paymentInfo =
                orderDao.getLatestNovalnetPaymentInfo(orderCode);

        final NnPaymentDetailsData details =
                new NnPaymentDetailsData();

        details.setStatus(
                paymentInfo.getPaymentGatewayStatus());
                
        details.setComments(
                paymentInfo.getOrderHistoryNotes());
        details.setTid(
                paymentInfo.getPaymentInfo());

        return details;
    }

    private Map<String, Object> buildPaymentRequest(
            final NnRequestData request,
            final String email,
            final int amount,
            final String currency,
            final String languageCode,
            final HttpServletRequest httpRequest) {

        final Map<String, Object> data = new HashMap<>();
        final Map<String, Object> transaction = new HashMap<>();
        final Map<String, Object> customer = new HashMap<>();
        final Map<String, Object> merchant = new HashMap<>();
        final Map<String, Object> custom = new HashMap<>();
        
        Map<String, Object> cartInfo = buildCartInfo(orderFacade.loadCart(request.getCartId()));

        merchant.put("signature",
                orderFacade.getBaseStoreModel().getNovalnetAPIKey());
        merchant.put("tariff",
                orderFacade.getBaseStoreModel().getNovalnetTariffId());
                
        final PaymentDetailsData paymentData = request.getPaymentData();
        final BookingData booking = paymentData.getBooking_details();
        
        if (paymentData == null) {
            throw new IllegalArgumentException("Payment data is missing in request");
        }
        
        transaction.put("system_name", "SAP Commerce Cloud");
        transaction.put("system_version", "2205-NN2.0.0");
        

        if (request.getReturnUrl() != null && !request.getReturnUrl().isEmpty()) {
            transaction.put("return_url", request.getReturnUrl());
            transaction.put("error_return_url", request.getReturnUrl());
        }
        
        final Map<String, Object> paymentDataMap =
                buildPaymentData(paymentData);

        if (!paymentDataMap.isEmpty()) {
            transaction.put("payment_data", paymentDataMap);
        }
        
        if (booking != null
                && "zero_amount".equalsIgnoreCase(booking.getPayment_action())) {
            transaction.put("amount", 0);
        } else {
            transaction.put("amount", amount);
        }
        
        transaction.put("test_mode", booking.getTest_mode());
        
        if (booking != null && booking.getCreate_token() != null
                && booking.getCreate_token() == 1) {
            transaction.put("create_token", 1);
        }
        
        if (booking != null  && booking.getDue_date() != null) {
            final String dueDate = addDaysToCurrentDate(booking.getDue_date());
            transaction.put("due_date", dueDate);
        }
        
        transaction.put("currency", currency);
        transaction.put("payment_type",
                request.getPaymentData()
                       .getPayment_details()
                       .getType());

        customer.put("email", email);
        customer.put("customer_no", orderFacade.getCurrentUserForCheckout().getCustomerID());
        customer.put("customer_ip", getClientIp(httpRequest));
        
        if(booking.getBirth_date() != null) {
            customer.put("birth_date", booking.getBirth_date());
        }
        
        if (request.getAddress() == null) {
            throw new IllegalArgumentException("Address object is missing in request");
        }

        final NnBillingData billingData =
                request.getAddress().getBillingAddress();
        final NnShippingData shippingData =
                request.getAddress().getShippingAddress();

        if (shippingData == null || shippingData.getAddressId() == null) {
            throw new IllegalArgumentException("Shipping addressId is mandatory");
        }

        final AddressModel shippingAddress =
                orderFacade.getShippingAddress(shippingData.getAddressId());

        if (shippingAddress == null) {
            throw new IllegalStateException(
                    "No address found for addressId: " + shippingData.getAddressId());
        }

        final Map<String, Object> billing;
        final Map<String, Object> shipping;

        if (Boolean.TRUE.equals(billingData.getSameAsdelivery())) {

            customer.put("first_name", shippingAddress.getFirstname());
            customer.put("last_name", shippingAddress.getLastname());

            billing = buildAddressFromAddressModel(shippingAddress);
            shipping = Map.of("same_as_billing", 1);

        } else {

            customer.put("first_name", billingData.getFirstName());
            customer.put("last_name", billingData.getLastName());

            billing = buildBillingAddress(billingData);
            shipping = buildAddressFromAddressModel(shippingAddress);
        }
        
        if (getCompanyNameForUser() != null ) {
            billing.put("company", getCompanyNameForUser());
        }

        customer.put("billing", billing);
        customer.put("shipping", shipping);

        custom.put("lang", languageCode);
        custom.put("input1", "cartId");
        custom.put("inputval1", request.getCartId());
        custom.put("input2", "payment_name");
        custom.put("inputval2", request.getPaymentData()
                       .getPayment_details()
                       .getName());

        data.put("merchant", merchant);
        data.put("transaction", transaction);
        data.put("customer", customer);
        data.put("custom", custom);
        data.put("cart_info", cartInfo);

        return data;
    }
    
    protected Map<String, Object> buildPaymentData(
            final PaymentDetailsData paymentData) {

        final Map<String, Object> payment = new HashMap<>();
        final BookingData booking = paymentData.getBooking_details();

        if (booking == null) {
            return payment;
        }

        if (booking.getPan_hash() != null) {
            payment.put("pan_hash", booking.getPan_hash());
            payment.put("unique_id", booking.getUnique_id());
        }

        if (booking.getIban() != null) {
            payment.put("iban", booking.getIban());
        }
        
        if (booking.getBic() != null) {
            payment.put("bic", booking.getBic());
        }

        if (booking.getAccount_holder() != null) {
            payment.put("account_holder", booking.getAccount_holder());
        }
        
        if (booking.getAccount_number() != null) {
            payment.put("account_number", booking.getAccount_number());
        }
        
        if (booking.getRouting_number() != null) {
            payment.put("routing_number", booking.getRouting_number());
        }

        if (booking.getWallet_token() != null) {
            payment.put("wallet_token", booking.getWallet_token());
        }
        
        if (booking.getToken() != null) {
            payment.put("token", booking.getToken());
        }
        
        final PaymentRefData paymentRef = booking.getPayment_ref();

        if (paymentRef != null 
                && "token".equals(paymentRef.getType()) 
                && paymentRef.getToken() != null) {
            
            payment.put("token", paymentRef.getToken());
        }

        return payment;
    }
    
    protected Map<String, Object> buildAddressFromAddressModel(
            final AddressModel addressModel) {

        final Map<String, Object> address = new HashMap<>();

        address.put(
                "street",
                addressModel.getLine1() +
                (addressModel.getLine2() != null ? " " + addressModel.getLine2() : "")
        );
        address.put("city", addressModel.getTown());
        address.put("zip", addressModel.getPostalcode());
        address.put("country_code", addressModel.getCountry().getIsocode());

        return address;
    }
    
    protected Map<String, Object> buildBillingAddress(
            final NnBillingData billing) {

        final Map<String, Object> address = new HashMap<>();

        address.put(
                "street",
                billing.getLine1() +
                (billing.getLine2() != null ? " " + billing.getLine2() : "")
        );
        address.put("city", billing.getTown());
        address.put("zip", billing.getPostalCode());
        address.put("country_code", billing.getCountry().getIsoCode());

        if (billing.getDob() != null) {
            address.put("birth_date", billing.getDob());
        }

        return address;
    }

    private String sendRequest(
            final String url,
            final String payload,
            final String accessKey) throws Exception {

        LOG.info("Sending Novalnet request -> " + url);
        
        LOG.info("Novalnet request payload -> " + payload);

        final URL endpoint = new URL(url);
        final HttpURLConnection con =
                (HttpURLConnection) endpoint.openConnection();

        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json");
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty(
                "X-NN-Access-Key",
                Base64.getEncoder()
                        .encodeToString(
                                accessKey.getBytes(StandardCharsets.UTF_8)));
        con.setDoOutput(true);

        con.getOutputStream()
           .write(payload.getBytes(StandardCharsets.UTF_8));

        final String response =
                new String(con.getInputStream().readAllBytes(),
                        StandardCharsets.UTF_8);

        LOG.info("Novalnet response received");
        LOG.info("Novalnet response data -> " + response);
        return response;
    }

    private int calculateOrderAmount(final CartData cart) {

        final String amount =
                formatAmount(
                        cart.getTotalPriceWithTax()
                            .getValue().toString());
                           
        final BigDecimal decimal =
                new BigDecimal(amount)
                        .multiply(BigDecimal.valueOf(100))
                        .setScale(0, RoundingMode.HALF_EVEN);

        return decimal.intValue();
    }

    private String formatAmount(final String amount) {

        if (amount.contains(",")) {
            try {
                final NumberFormat nf =
                        NumberFormat.getNumberInstance(
                                Locale.GERMANY);
                return nf.parse(amount).toString();
            } catch (Exception ex) {
                return amount.replace(",", ".");
            }
        }
        return amount;
    }

    private boolean isAuthorize(final NnRequestData request) {
        return request.getPaymentData()
                      .getBooking_details()
                      .getPayment_action() != null
            && "authorized".equalsIgnoreCase(
                    request.getPaymentData()
                           .getBooking_details()
                           .getPayment_action());
    }
    
    public OrderData placeOrderFromTid(final NnRequestData request) {

        try {
            
            final BaseStoreModel baseStore = orderFacade.getBaseStoreModel();

            final String tid = request.getTid();
            final String cartID = request.getCartId();
            
            if (tid == null || tid.isBlank()) {
                throw new IllegalArgumentException("Transaction ID (TID) is required");
            }
            
            final JSONObject transactionResponse =
                    fetchTransactionDetailsFromNovalnet(tid, baseStore);
                    
            final JSONObject result =
                transactionResponse.optJSONObject("result");

            if (result == null) {
                throw new IllegalStateException("Invalid Novalnet response: result missing");
            }

            final String status =
                    result.optString("status");

            if (!"SUCCESS".equalsIgnoreCase(status)) {
                throw new IllegalStateException(
                        "Transaction not successful: "
                                + result.optString("status_text",
                                result.optString("status_desc")));
            }

            final JSONObject transaction =
                    transactionResponse.optJSONObject("transaction");

            if (transaction == null) {
                throw new IllegalStateException("Transaction object missing in response");
            }

            OrderData order = orderFacade.createOrderFromNovalnetResponse(transactionResponse, cartID);

            syncOrderWithNovalnet(order.getCode(), tid);

            return order;
            
        } catch (Exception ex) {
            LOG.error("Place order from TID failed", ex);
            throw new IllegalStateException(
                    "Unable to place order for Novalnet transaction", ex);
        }
    }

    protected void syncOrderWithNovalnet(
        final String orderCode, 
        final String tid) {
            
        try {

            final BaseStoreModel baseStore = orderFacade.getBaseStoreModel();

            final Map<String, Object> data = new HashMap<>();
            final Map<String, Object> transaction = new HashMap<>();
            final Map<String, Object> custom = new HashMap<>();

            transaction.put("tid", tid);
            transaction.put("order_no", orderCode);
            
            custom.put("lang", orderFacade.getLanguage());

            data.put("transaction", transaction);
            data.put("custom", custom);

            sendRequest(
                "https://payport.novalnet.de/v2/transaction/update",
                gson.toJson(data),
                baseStore.getNovalnetPaymentAccessKey());
        } catch (Exception ex) {
            LOG.error("Error while calling Novalnet API", ex);
            throw new IllegalStateException(
                    "Failed to communicate with Novalnet", ex);
        }
    }
    
    protected JSONObject fetchTransactionDetailsFromNovalnet(
        final String tid,
        final BaseStoreModel baseStore) {

        final Map<String, Object> request = Map.of(
                "transaction", Map.of("tid", tid),
                "custom", Map.of("lang", orderFacade.getLanguage())
        );

        final String accessKey =
                baseStore.getNovalnetPaymentAccessKey();

        if (accessKey == null || accessKey.isBlank()) {
            throw new IllegalStateException("Novalnet access key not configured");
        }

        try {
            final String response =
                    sendRequest(
                            TRANSACTION_DETAILS_URL,
                            gson.toJson(request),
                            accessKey);

            return new JSONObject(response);

        } catch (Exception ex) {
            LOG.error("Failed to fetch transaction details", ex);
            throw new IllegalStateException(
                    "Unable to fetch transaction details from Novalnet", ex);
        }
    }
    
    public NnPaymentResponseData getHostedPaymentUrl(
        final NnRequestData request,
        final HttpServletRequest httpRequest) {

        final NnPaymentResponseData response =
                new NnPaymentResponseData();

        try {
            final CartData cart = orderFacade.loadCart(request.getCartId());
            final BaseStoreModel baseStore = orderFacade.getBaseStoreModel();

            final int orderAmountCents =
                    calculateOrderAmount(cart);
            final String currency =
                    cart.getTotalPriceWithTax().getCurrencyIso();
            final String email =
                    orderFacade.getCurrentUserForCheckout().getUid();
                    
            final Map<String, Object> payload =
                    buildHostedPaymentRequest(
                            request,
                            email,
                            orderAmountCents,
                            currency,
                            orderFacade.getLanguage(),
                            httpRequest);

            final String novalnetResponse =
                    sendRequest(
                            "https://payport.novalnet.de/v2/seamless/payment",
                            gson.toJson(payload),
                            baseStore.getNovalnetPaymentAccessKey());

            final JSONObject json =
                    new JSONObject(novalnetResponse);
            final JSONObject result =
                    json.getJSONObject("result");

            if (!"100".equals(result.get("status_code").toString())) {
                response.setError(
                        result.optString("status_text",
                                result.optString("status_desc")));
                return response;
            }

            response.setPaymentURL(
                    result.getString("redirect_url"));
            return response;

        } catch (Exception ex) {
            LOG.error("Hosted payment URL failed", ex);
            response.setError(
                    "Unable to generate Novalnet payment URL");
            return response;
        }
    }
    
    private Map<String, Object> buildHostedPaymentRequest(
            final NnRequestData request,
            final String email,
            final int amount,
            final String currency,
            final String languageCode,
            final HttpServletRequest httpRequest) {

        final Map<String, Object> data = new HashMap<>();
        final Map<String, Object> transaction = new HashMap<>();
        final Map<String, Object> merchant = new HashMap<>();
        final Map<String, Object> customer = new HashMap<>();
        final Map<String, Object> custom = new HashMap<>();
        final Map<String, Object> hostedPage = new HashMap<>();

        final BaseStoreModel baseStore =
                orderFacade.getBaseStoreModel();

        merchant.put("signature", baseStore.getNovalnetAPIKey());
        merchant.put("tariff", baseStore.getNovalnetTariffId());

        transaction.put("amount", amount);
        transaction.put("currency", currency);
        transaction.put("system_name", "sap_commerce_occ");
        transaction.put("system_version", "2205-NN2.0.0-NNTSpartacus");

        hostedPage.put("type", "PAYMENTFORM");

        customer.put("email", email);
        customer.put("customer_no", orderFacade.getCurrentUserForCheckout().getCustomerID());
        customer.put("customer_ip", getClientIp(httpRequest));
        
        final NnBillingData billingData =
                request.getBillingAddress();
        final NnShippingData shippingData =
                request.getShippingAddress();

        if (Boolean.TRUE.equals(billingData.getSameAsdelivery()) && shippingData == null || shippingData.getAddressId() == null) {
            throw new IllegalArgumentException("Shipping addressId is mandatory");
        }

        final AddressModel shippingAddress =
                orderFacade.getShippingAddress(shippingData.getAddressId());

        if (Boolean.TRUE.equals(billingData.getSameAsdelivery()) && shippingAddress == null) {
            throw new IllegalStateException(
                    "No address found for addressId: " + shippingData.getAddressId());
        }

        final Map<String, Object> billing;
        final Map<String, Object> shipping;

        if (Boolean.TRUE.equals(billingData.getSameAsdelivery())) {

            customer.put("first_name", shippingAddress.getFirstname());
            customer.put("last_name", shippingAddress.getLastname());

            billing = buildAddressFromAddressModel(shippingAddress);
            shipping = Map.of("same_as_billing", 1);

        } else {

            customer.put("first_name", billingData.getFirstName());
            customer.put("last_name", billingData.getLastName());

            billing = buildBillingAddress(billingData);
            shipping = buildAddressFromAddressModel(shippingAddress);
        }
        
        if (getCompanyNameForUser() != null ) {
            billing.put("company", getCompanyNameForUser());
        }

        customer.put("billing", billing);
        customer.put("shipping", shipping);
        

        custom.put("lang", languageCode);

        data.put("merchant", merchant);
        data.put("transaction", transaction);
        data.put("customer", customer);
        data.put("custom", custom);
        data.put("hosted_page", hostedPage);

        return data;
    }

    public String getCompanyNameForUser() {

        UserModel user = orderFacade.getCurrentUserForCheckout();

        if (user instanceof B2BCustomerModel) {
            B2BCustomerModel b2bCustomer = (B2BCustomerModel) user;
            B2BUnitModel unit = b2bCustomer.getDefaultB2BUnit();

            if (unit != null) {
                return unit.getName(); 
            }
        }

        return null;
    }
    
    public static String getClientIp(final HttpServletRequest request)
    {
        String ip = request.getHeader("X-Forwarded-For");

        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Real-IP");
        }

        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }

        // Normalize IPv6 localhost
        if ("0:0:0:0:0:0:0:1".equals(ip) || "::1".equals(ip)) {
            ip = "127.0.0.1";
        }

        // Handle multiple IPs in X-Forwarded-For
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }

        return ip;
    }
    
    public static String addDaysToCurrentDate(final String daysToAddStr)
    {
        int daysToAdd = 0;

        try
        {
            daysToAdd = Integer.parseInt(daysToAddStr);
        }
        catch (NumberFormatException e)
        {
            // SAP Commerce standard: fallback safely
            // You may log this if required
            daysToAdd = 0;
        }
        
        if(daysToAdd != 0) { 

            final Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            calendar.add(Calendar.DAY_OF_MONTH, daysToAdd);

            final SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
            return sdf.format(calendar.getTime());
        }
        
        return ""; 
        
    }

    
    public NnConfigData getPaymentConfiguration() {

        final BaseStoreModel baseStore =
                orderFacade.getBaseStoreModel();

        final PaymentModeModel paymentMode =
                orderFacade.getNovalnetPaymentMode();

        final NovalnetPaymentModeModel novalnetMode =
                (NovalnetPaymentModeModel) paymentMode;

        final NnConfigData config = new NnConfigData();

        config.setNovalnetAccessKey(
                baseStore.getNovalnetPaymentAccessKey());
        config.setNovalnetActive(
                Boolean.TRUE.equals(novalnetMode.getActive()));
        config.setNovalnetDisplayPayment(
                baseStore.getNovalnetDisplayPayments());

        return config;
    }
    
    public Map<String, Object> buildCartInfo(final CartData cartData) {

        if (cartData == null) {
            throw new IllegalArgumentException("Cart data not found");
        }

        final Map<String, Object> cartInfo = new HashMap<>();
        final List<Map<String, Object>> lineItems = new ArrayList<>();

        for (final OrderEntryData entry : cartData.getEntries()) {

            final Map<String, Object> item = new HashMap<>();
            final ProductData product = entry.getProduct();

            item.put("category", "physical");
            item.put("description", product.getDescription());
            item.put("name", product.getName());

            // Prefer total price (includes entry-level discounts)
            final long priceInCents = entry.getTotalPrice() != null
                    ? entry.getTotalPrice()
                        .getValue()
                        .multiply(BigDecimal.valueOf(100))
                        .setScale(0, RoundingMode.HALF_UP)
                        .longValue()
                    : 0L;

            item.put("price", priceInCents);
            item.put("quantity", entry.getQuantity().intValue());

            lineItems.add(item);
        }

        final long discountAmount = cartData.getTotalDiscounts() != null
                ? cartData.getTotalDiscounts()
                    .getValue()
                    .multiply(BigDecimal.valueOf(100))
                    .setScale(0, RoundingMode.HALF_UP)
                    .negate()
                    .longValue()
                : 0L;

        if (discountAmount != 0L) {

            final Map<String, Object> discountItem = new HashMap<>();

            discountItem.put("name", "Discount");
            discountItem.put("price", discountAmount);
            discountItem.put("quantity", 1);

            lineItems.add(discountItem);
        }

        cartInfo.put("line_items", lineItems);

        final long shippingPrice = cartData.getDeliveryCost() != null
                ? cartData.getDeliveryCost()
                    .getValue()
                    .multiply(BigDecimal.valueOf(100))
                    .setScale(0, RoundingMode.HALF_UP)
                    .longValue()
                : 0L;

        cartInfo.put("items_shipping_price", shippingPrice);

        final long taxPrice = cartData.getTotalTax() != null
                ? cartData.getTotalTax()
                    .getValue()
                    .multiply(BigDecimal.valueOf(100))
                    .setScale(0, RoundingMode.HALF_UP)
                    .longValue()
                : 0L;

        cartInfo.put("items_tax_price", taxPrice);

        final long totalAmount = cartData.getTotalPrice() != null
                ? cartData.getTotalPrice()
                    .getValue()
                    .multiply(BigDecimal.valueOf(100))
                    .setScale(0, RoundingMode.HALF_UP)
                    .longValue()
                : 0L;

        //~ cartInfo.put("items_handling_price", totalAmount);

        return cartInfo;
    }


}

import { HttpClient } from '@angular/common/http';
import { Component, OnDestroy } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { EventService, GlobalMessageService, OccEndpointsService, TranslationService } from '@spartacus/core';
import { OrderDetailsService } from '@spartacus/order/components';
import { OrderService } from '@spartacus/order/core';
import { Order, OrderFacade, OrderHistoryFacade } from '@spartacus/order/root';
import { Observable } from 'rxjs';
import { NovalnetService } from '../novalnet-service/novalnet-service';
import { ClearCartDialogComponentService } from '@spartacus/cart/base/components';
import { ActiveCartService } from '@spartacus/cart/base/core';

import { ChangeDetectionStrategy } from '@angular/core';
import { CartOutlets } from '@spartacus/cart/base/root';
import { combineLatest, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { OrderOutlets, paymentMethodCard } from '@spartacus/order/root';
import * as i0 from "@angular/core";
import * as i1 from "@spartacus/core";
import * as i2 from '@spartacus/order';
import * as i3 from "@spartacus/storefront";
import * as i4 from "@angular/common";
import * as i5 from '@spartacus/order';
import { ReplenishmentOrder } from '@spartacus/order/root';



@Component({
  selector: 'novalnet-order-confirmation-overview',
  templateUrl: './order-confirmation-overview.component.html',
  styleUrls: ['./order-confirmation-overview.component.scss'] 
})
export class NovalnetOrderConfirmationOverviewComponent {
  simple$: any;
  cartOutlets: typeof CartOutlets;
  orderOutlets: typeof OrderOutlets;
  isOrderLoading$: Observable<boolean>;
  occEndpoint: OccEndpointsService;
  placedOrder: any;
  novalnetService: NovalnetService;
  http: HttpClient;
  order$: Observable<Order> | undefined;
  



  constructor(private orderDetailsService:OrderDetailsService, private translation:TranslationService, occEndpoint:OccEndpointsService, novalnetService:NovalnetService, http:HttpClient, private orderFacade:OrderFacade) {
    this.http = http;
    this.cartOutlets = CartOutlets;
    this.orderFacade = orderFacade;
    this.translation = translation;
    this.orderDetailsService = orderDetailsService;
    this.occEndpoint = occEndpoint;
    this.novalnetService = novalnetService;
    this.placedOrder = this.novalnetService.getOrder();
    let requestURL = this.occEndpoint.getBaseUrl()+ "/users/current/orders/"+this.placedOrder.code;
    this.http.get(requestURL).subscribe((data:any) => { this.orderFacade.setPlacedOrder(data);});
    this.orderOutlets = OrderOutlets;
    this.isOrderLoading$ = typeof this.orderDetailsService.isOrderDetailsLoading === 'function'
        ? this.orderDetailsService.isOrderDetailsLoading()
        : of(true);

            
  }
  
  ngOnInit() {
    this.order$ = this.orderDetailsService.getOrderDetails();
        this.isOrderLoading$ = typeof this.orderDetailsService.isOrderDetailsLoading === 'function'
            ? this.orderDetailsService.isOrderDetailsLoading()
            : of(true);    
  }

  getReplenishmentCodeCardContent(orderCode: any) {
    return this.translation.translate('orderDetails.replenishmentId').pipe(filter(() => Boolean(orderCode)), map((textTitle) => ({
        title: textTitle,
        text: [orderCode],
    })));
}
getReplenishmentActiveCardContent(active: any) {
    return combineLatest([
        this.translation.translate('orderDetails.status'),
        this.translation.translate('orderDetails.active'),
        this.translation.translate('orderDetails.cancelled'),
    ]).pipe(map(([textTitle, textActive, textCancelled]) => ({
        title: textTitle,
        text: [active ? textActive : textCancelled],
    })));
}
getReplenishmentStartOnCardContent(isoDate: any) {
    return this.translation.translate('orderDetails.startOn').pipe(filter(() => Boolean(isoDate)), map((textTitle) => {
        return {
            title: textTitle,
            text: [isoDate],
        };
    }));
}
getReplenishmentFrequencyCardContent(frequency: any) {
    return this.translation.translate('orderDetails.frequency').pipe(filter(() => Boolean(frequency)), map((textTitle) => ({
        title: textTitle,
        text: [frequency],
    })));
}
getReplenishmentNextDateCardContent(isoDate: any) {
    return this.translation.translate('orderDetails.nextOrderDate').pipe(filter(() => Boolean(isoDate)), map((textTitle) => {
        return {
            title: textTitle,
            text: [isoDate],
        };
    }));
}
getOrderCodeCardContent(orderCode: any) {
    return this.translation.translate('orderDetails.orderNumber').pipe(filter(() => Boolean(orderCode)), map((textTitle) => ({
        title: textTitle,
        text: [orderCode],
    })));
}
getOrderCurrentDateCardContent(isoDate: any) {
    return this.translation.translate('orderDetails.placedOn').pipe(filter(() => Boolean(isoDate)), map((textTitle) => {
        return {
            title: textTitle,
            text: [isoDate],
        };
    }));
}
getOrderStatusCardContent(status: any) {
    return combineLatest([
        this.translation.translate('orderDetails.status'),
        this.translation.translate('orderDetails.statusDisplay_' + status),
    ]).pipe(map(([textTitle, textStatus]) => ({
        title: textTitle,
        text: [textStatus],
    })));
}
getPurchaseOrderNumber(poNumber: any) {
    return combineLatest([
        this.translation.translate('orderDetails.purchaseOrderNumber'),
        this.translation.translate('orderDetails.emptyPurchaseOrderId'),
    ]).pipe(map(([textTitle, noneTextTitle]) => ({
        title: textTitle,
        text: [poNumber ? poNumber : noneTextTitle],
    })));
}
getMethodOfPaymentCardContent(hasPaymentInfo: any) {
    return combineLatest([
        this.translation.translate('orderDetails.methodOfPayment'),
        this.translation.translate('paymentTypes.paymentType_ACCOUNT'),
        this.translation.translate('paymentTypes.paymentType_CARD'),
    ]).pipe(map(([textTitle, textAccount, textCard]) => ({
        title: textTitle,
        text: [Boolean(hasPaymentInfo) ? textCard : textAccount],
    })));
}
getCostCenterCardContent(costCenter: { name: any; unit: { name: string; }; }|any) {
    return this.translation.translate('orderDetails.costCenter').pipe(filter(() => Boolean(costCenter)), map((textTitle) => ({
        title: textTitle,
        textBold: costCenter?.name,
        text: ['(' + costCenter?.unit?.name + ')'],
    })));
}
getAddressCardContent(deliveryAddress: { formattedAddress: any; firstName: any; lastName: any; country: { name: any; }; }|any) {
    return this.translation.translate('addressCard.shipTo').pipe(filter(() => Boolean(deliveryAddress)), map((textTitle) => {
        const formattedAddress = this.normalizeFormattedAddress(deliveryAddress.formattedAddress ?? '');
        return {
            title: textTitle,
            textBold: `${deliveryAddress.firstName} ${deliveryAddress.lastName}`,
            text: [formattedAddress, deliveryAddress.country?.name],
        };
    }));
}
getDeliveryModeCardContent(deliveryMode: { name: any; description: any; deliveryCost: { formattedValue: any; }; }|any) {
    return this.translation.translate('orderDetails.shippingMethod').pipe(filter(() => Boolean(deliveryMode)), map((textTitle) => ({
        title: textTitle,
        textBold: deliveryMode.name,
        text: [
            deliveryMode.description,
            deliveryMode.deliveryCost?.formattedValue
                ? deliveryMode.deliveryCost?.formattedValue
                : '',
        ],
    })));
}
getPaymentInfoCardContent(payment: i1.PaymentDetails|any) {
    return combineLatest([
        this.translation.translate('paymentForm.payment'),
        this.translation.translate('paymentCard.expires', {
            month: Boolean(payment) ? payment.expiryMonth : '',
            year: Boolean(payment) ? payment.expiryYear : '',
        }),
    ]).pipe(filter(() => Boolean(payment)), map(([textTitle, textExpires]) => paymentMethodCard(textTitle, textExpires, payment)));
}
isPaymentInfoCardFull(payment: { cardNumber: any; expiryMonth: any; expiryYear: any; }|any) {
    return (!!payment?.cardNumber && !!payment?.expiryMonth && !!payment?.expiryYear);
}
getBillingAddressCardContent(billingAddress: { firstName: any; lastName: any; formattedAddress: any; country: { name: any; }; }|any) {
    return this.translation.translate('paymentForm.billingAddress').pipe(filter(() => Boolean(billingAddress)), map((textTitle) => ({
        title: textTitle,
        textBold: `${billingAddress.firstName} ${billingAddress.lastName}`,
        text: [
            billingAddress.formattedAddress,
            billingAddress.country?.name,
        ],
    })));
}
normalizeFormattedAddress(formattedAddress: string) {
    const addresses = formattedAddress
        .split(',')
        .map((address: string) => address.trim());
    return addresses.filter(Boolean).join(', ');
}


  

}

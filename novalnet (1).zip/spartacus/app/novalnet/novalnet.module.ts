import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CmsConfig, ConfigModule, I18nModule, provideConfig, UrlModule} from '@spartacus/core';
import { NovalnetPaymentDetailsComponentComponent } from './novalnet-payment-details/novalnet-payment-details.component';
import { AtMessageModule, CardModule, FormErrorsModule, NgSelectA11yModule, OutletModule, PromotionsModule, PwaModule, SpinnerModule } from '@spartacus/storefront';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { CartNotEmptyGuard, CheckoutAuthGuard, CheckoutProgressComponent, CheckoutProgressMobileBottomComponent, CheckoutProgressMobileTopComponent, CheckoutPaymentMethodModule } from '@spartacus/checkout/base/components';
import { NovalnetCheckoutPlaceOrderComponent } from './novalnet-place-order-component/place-order-component';
import { RouterModule } from '@angular/router';
import { OrderModule } from '@spartacus/order';
import { OrderConfirmationComponent } from './order-confirmation/order-confirmation.component';
import { NovalnetorderDetailsComponent } from './novalnet-order-details/novalnet-order-details.component';
import { NovalnetOrderConfirmationOverviewComponent } from './order-confirmation/order-confirmation-overview.component';
import { OrderComponentsModule, OrderConfirmationModule, OrderGuestRegisterFormComponent} from '@spartacus/order/components';
import { checkoutB2BTranslationChunksConfig, checkoutB2BTranslations } from '@spartacus/checkout/b2b/assets';
import { checkoutTranslationChunksConfig, checkoutTranslations } from '@spartacus/checkout/base/assets';
import { translationChunksConfig } from '@spartacus/assets';
import { CheckoutStepType } from '@spartacus/checkout/base/root/model';
import { CheckoutModule } from '@spartacus/checkout/base';


@NgModule({
  declarations: [ NovalnetPaymentDetailsComponentComponent, NovalnetCheckoutPlaceOrderComponent, OrderConfirmationComponent, NovalnetOrderConfirmationOverviewComponent, NovalnetorderDetailsComponent ],
  imports: [
    CommonModule,
    I18nModule,
    CardModule,
    FormsModule,
    FormErrorsModule,
    NgSelectModule,
    NgSelectA11yModule,
    SpinnerModule,
    ReactiveFormsModule,
    SpinnerModule,
    AtMessageModule,
    RouterModule,
    UrlModule,
    OrderModule,
    OrderConfirmationModule,
    PwaModule,
    PromotionsModule,
    OutletModule,
    ConfigModule.withConfig({} as CmsConfig),
    CheckoutPaymentMethodModule,
    CheckoutModule 
],
  exports:[],
  providers: [
    provideConfig({
      cmsComponents : {
        CheckoutPaymentDetails : {
          component : NovalnetPaymentDetailsComponentComponent,
        },
        CheckoutProgressMobileBottom: {
          component: CheckoutProgressMobileBottomComponent,
          guards: [CheckoutAuthGuard, CartNotEmptyGuard],
        },
        CheckoutProgress: {
            component: CheckoutProgressComponent,
            guards: [CheckoutAuthGuard, CartNotEmptyGuard],
        },
        CheckoutProgressMobileTop: {
          component: CheckoutProgressMobileTopComponent,
          guards: [CheckoutAuthGuard, CartNotEmptyGuard],
        },
        CheckoutPlaceOrder: {
          component : NovalnetCheckoutPlaceOrderComponent,
        },
        OrderConfirmationThankMessageComponent :{
          component : OrderConfirmationComponent,
        },
        OrderConfirmationOverviewComponent: {
          component: NovalnetOrderConfirmationOverviewComponent,
        },
        AccountOrderDetailsReorderComponent :{
          component : NovalnetorderDetailsComponent,
        }
      },
      checkout: {
        steps: [
          {
            id: 'deliveryAddress',
            name: 'checkoutProgress.deliveryAddress',
            routeName: 'checkoutDeliveryAddress',
            type: [CheckoutStepType.DELIVERY_ADDRESS],
          },
          {
            id: 'deliveryMode',
            name: 'checkoutProgress.deliveryMode',
            routeName: 'checkoutDeliveryMode',
            type: [CheckoutStepType.DELIVERY_MODE],
          },
          {
            id: 'paymentDetails',
            name: 'checkoutProgress.paymentDetails',
            routeName: 'checkoutPaymentDetails',
            type: [CheckoutStepType.PAYMENT_DETAILS],
          },
          {
            id: 'reviewOrder',
            name: 'checkoutProgress.reviewOrder',
            routeName: 'checkoutReviewOrder',
            type: [CheckoutStepType.REVIEW_ORDER],
          },
        ]
      },
      i18n: {
        resources: checkoutTranslations,
        chunks: checkoutTranslationChunksConfig,
      }
    }),
    
  ],
})

export class NovalnetModule {

}

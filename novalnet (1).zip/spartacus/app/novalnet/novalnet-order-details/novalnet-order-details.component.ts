import { HttpClient } from '@angular/common/http';
import { Component, ViewContainerRef, ElementRef, ViewChild } from '@angular/core';
import { OccEndpointsService, RoutingService} from '@spartacus/core';
import { OrderDetailsService } from '@spartacus/order/components';
import { Order } from '@spartacus/order/root';
import { observable, Observable, Subscription } from 'rxjs';
import { combineLatest } from 'rxjs';
import { filter, map } from 'rxjs/operators'; 
import {LaunchDialogService} from '@spartacus/storefront'; 
import {take} from 'rxjs/operators';   

@Component({
  selector: 'cx-order-details-actions',
  templateUrl: './novalnet-order-details.component.html',
  styleUrls: ['./novalnet-order-details.component.scss'] 
})
export class NovalnetorderDetailsComponent {
	@ViewChild('element', { static: false })
	element!: ElementRef<HTMLButtonElement>;

 orderDetailsService: OrderDetailsService; 
 routingService: RoutingService;
  order$: Observable<Order>;
  occEndpoint: OccEndpointsService;
  http: HttpClient;
  orderData: any;
  done:Boolean;
  launchDialogService: LaunchDialogService;
  vcr: ViewContainerRef;
  subscription:Subscription;

  constructor(orderDetailsService:OrderDetailsService, occEndpoint:OccEndpointsService, http:HttpClient, routingService: RoutingService, launchDialogService: LaunchDialogService, vcr: ViewContainerRef) { 
    this.orderDetailsService = orderDetailsService;
    this.routingService = routingService;
    this.order$ = new Observable<Order>
    this.occEndpoint = occEndpoint;
    this.http = http;
    this.done = false;
    this.launchDialogService = launchDialogService;
	this.vcr = vcr;
	this.subscription = new Subscription();
  }
  
  ngOnInit() {
    this.order$ = combineLatest([
	  this.orderDetailsService.getOrderDetails(), 
	  this.routingService.getRouterState()
	]).pipe(
	  filter(([order, router]) =>
		order?.code === router.state?.params?.['orderCode']
	  ),
	  map(([order]) => order)
	);
  }


  appendTxnDetails(shopOrderNo:any) { 		
    if(shopOrderNo != "" && !this.done) {
      this.done = true;
      let requestURL = this.occEndpoint.getBaseUrl()+ "/novalnet/orders/paymentDetails?orderno="+shopOrderNo;
      this.http.post(requestURL, {"orderno" : shopOrderNo}).subscribe((data:any) => {
      document.getElementsByClassName('nn_txn_message')[0].innerHTML = data.comments;});
    }
  }
  
  onReorderClick(order:any) {
    this.launchDialog(order.code);
  }
    
  launchDialog(orderCode:any) { 

    const dialog = this.launchDialogService.openDialog("REORDER" /* LAUNCH_CALLER.REORDER */, this.element, this.vcr, { orderCode });
    if (dialog) {
        this.subscription.add(dialog.pipe(take(1)).subscribe());
    }
  }
  
  ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }


}
